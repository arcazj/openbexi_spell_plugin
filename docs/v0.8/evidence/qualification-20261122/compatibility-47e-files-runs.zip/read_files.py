import json
from pathlib import Path
import subprocess

folder = Path(__file__).resolve().parent / "fileswhole/files47a"
case = json.loads((folder / "case.json").read_bytes())
inspect = """
from pathlib import Path
import hashlib,json,stat
base=Path('/work')
entries={}
for path in sorted(base.rglob('*')):
    relative=path.relative_to(base)
    if not relative.parts[0].startswith(('files-owned-','files-basename-')):continue
    meta=path.lstat()
    item={'mode':oct(stat.S_IMODE(meta.st_mode)),'directory':path.is_dir()}
    if path.is_file():
        contents=path.read_bytes()
        assert len(contents)<1024
        item.update(size=len(contents),sha256=hashlib.sha256(contents).hexdigest(),hex=contents.hex())
    entries[relative.as_posix()]=item
print(json.dumps(entries,sort_keys=True))
"""
cmd = ["docker","run","--rm","--network","none","--read-only","--user","10003:10003",
       "--cap-drop","ALL","--security-opt","no-new-privileges","--mount",
       "type=volume,src="+case["volume"]+",dst=/work,volume-subpath=oracle-output,readonly,volume-nocopy",
       "--entrypoint","python",case["server_image"],"-I","-c",inspect]
rows=json.loads(subprocess.check_output(cmd))
(folder/"stored-files.json").write_bytes((json.dumps(rows,indent=2)+"\n").encode())
print(len(rows), sum(not x['directory'] for x in rows.values()))

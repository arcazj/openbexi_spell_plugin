from datetime import datetime,timezone
import hashlib,re,importlib.metadata,importlib.util,json,os,subprocess,sys,time,uuid
from pathlib import Path
from openbexi_runtime import spell_server_client as client_module
from openbexi_runtime.spell_server_client import SpellServerClient, SpellServerError
root=Path('C:/projects/openbexi_spell_plugin');base=Path(__file__).resolve().parent
suite,name=sys.argv[1:3];folder=base/suite/name; case=json.loads((folder/'case.json').read_bytes()); prefix=case['prefix']; worker=prefix+'-worker'
digest=lambda b:hashlib.sha256(b).hexdigest()
def docker(*cmd):
 p=subprocess.run(['docker',*map(str,cmd)],capture_output=True,timeout=30)
 p.check_returncode();return p.stdout
def save(n,v): (folder/n).write_bytes((json.dumps(v,indent=2)+'\n').encode())
def stamp():return datetime.now(timezone.utc).isoformat()
def poll(func,seconds):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  try: answer=func()
  except SpellServerError as failure:
   if failure.status!=503 or failure.code!='gateway_unavailable': raise
   report.setdefault('observation_transients',[]).append({'utc':stamp(),'status':failure.status,'code':failure.code});save('attempt.json',report);answer=None
  if answer:return answer
  time.sleep(.65)
 raise TimeoutError('Host observation deadline expired')
report={'suite':suite,'case':name,'started':stamp(),'worker_image':case['worker_image'],'server_image':case['server_image'],'snapshot_sha256':case['source_sha256'],'snapshot_git':case['revision'],'ide_client_sha256':digest(Path(client_module.__file__).read_bytes()),'ide_version':importlib.metadata.version('openbexi-ide'),'passed':False,'phases':[]}
assert report['ide_client_sha256']=='7694c8c3d2094ab84ee2e47465ab2481df5bd3af595642ab66f550c19bfc44fd'
assert report['worker_image']=='sha256:489ff81aaa52ecbf09b4281499ed00f22fdd8b19e51e133a0202f2bbb6a40413'
assert report['server_image']=='sha256:b1b46dcda1f8db45889f6a145d2125362bbc04c41ded6e956ea99ca1ea61f968'
adapter=root/'docs/v0.8/evidence/qualification-20261122/compatibility-admitted-oracle.py'; assert digest(adapter.read_bytes())=='c59f7551abca31f105299241af24ac6d5084104e7f297526f5bc415ecbab8bd8'
sp=importlib.util.spec_from_file_location('arch',adapter);arch=importlib.util.module_from_spec(sp);sp.loader.exec_module(arch)
assert suite=='fileswhole';spec={'name':suite,'result':'data-files-results.json'}
selection=json.loads((root/'conformance/evidence/files.json').read_bytes())['checks']
arch.protected_inputs(root); key=lambda:str(uuid.uuid4())
client=SpellServerClient.from_config(folder/'alice/connection.json')
def phase(n): report['phases'].append({'phase':n,'utc':stamp()});save('attempt.json',report)
try:
 phase('catalog'); procs=client.read('A','procedures')['procedures'];assert len(procs)==1
 proc=procs[0];assert proc['runtime_image']==case['worker_image'] and proc['source_sha256']==case['source_sha256'] and proc['source_revision']==case['revision']
 cid=client.authority('A','session.open',{},key=key())['connection_id']; inputs={n:proc[n] for n in ('procedure_id','source_revision','source_sha256','runtime_image','driver_binding')}
 reservation=client.authority('A','execution.reserve',dict(inputs,connection_id=cid),key=key());eid=reservation['id'];report['execution_id']=eid; assert client.remember_controller('A',reservation)
 phase('reserved')
 admitted=client.launch('A',eid,key=key());assert admitted['execution_id']==eid and admitted['state']=='ADMITTED';report['launch_receipt']=admitted; phase('admitted')
 def current():return next(v for v in client.read('A','executions')['executions'] if v['id']==eid)
 poll(lambda:current().get('native_root_registered'),35);phase('native-root-registered')
 cmd=client.command('A',eid,'CMD_RUN',key=key());report['run_status']=cmd.get('state',cmd.get('status'));phase('run-command-accepted')
 prompts={};answered=set();names=dict(A='ABORT',R='REPEAT',S='RESEND',C='RECHECK',K='SKIP',N='NOACTION',Q='CANCEL',H='HANDLE')
 def run_with_owner_prompts():
  terminal=current().get('native_root_result')
  if terminal:return terminal
  prompt=client.prompt('A',eid,key=key())
  if not prompt or prompt['prompt_id'] in answered:return None
  mount="type=volume,src="+case['volume']+",dst=/work,volume-subpath=oracle-output,volume-nocopy"
  helper=['run','--rm','--network','none','--read-only','--user','10003:10003','--cap-drop','ALL','--security-opt','no-new-privileges','--entrypoint','python']
  active=json.loads(docker(*helper,'--mount',mount+',readonly',case['server_image'],'-I','-c',"from pathlib import Path;print(Path('/work/data-files-active.json').read_text())"))
  check=active['check'];rows=prompts.setdefault(check,[]);index=len(rows);expected=active['prompts'][index]
  original=selection[check]['controller_prompts'][index]
  choices=[names.get(ch,ch) for ch in prompt['choices']];relative=expected['repair']
  assert expected['answer']=='REPEAT' and expected['choices']==original['choices']==['REPEAT','SKIP']
  assert re.fullmatch(r'files-owned-[a-f0-9]{32}/repair',relative)
  assert re.sub(r'files-owned-[a-f0-9]{32}', 'files-owned-instance',prompt['text'])==re.sub(r'files-owned-[a-f0-9]{32}', 'files-owned-instance',original['text'])
  assert len(choices)==2 and set(choices)==set(expected['choices']),(check,choices)
  repaired=json.loads(docker(*helper,'--mount',mount,case['server_image'],'-I','-c',
         "import hashlib,json,sys;from pathlib import Path;p=Path('/work',sys.argv[1]);assert not p.exists();p.write_bytes(b'controller repaired'+bytes([10]));print(json.dumps({'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}))",relative))
  reply={k:prompt[k] for k in ('prompt_id','definition_sha256','target_admission_id')};reply.update(action='ANSWER',answer=str(choices.index(expected['answer'])));answered.add(prompt['prompt_id'])
  try:receipt=client.prompt('A',eid,key=key(),reply=reply)
  except SpellServerError as failure:raise RuntimeError('Owner reply outcome uncertain: '+str(failure)) from failure
  rows.append(dict(prompt_id=prompt['prompt_id'],definition_sha256=prompt['definition_sha256'],choices=choices,text=prompt['text'],expected=expected,repair_receipt=repaired,source_action='ANSWER',state=receipt.get('state')));answered.add(prompt['prompt_id']);save('controller-prompts.json',prompts);return None
 result=poll(run_with_owner_prompts,300);report['authoritative_native_status']=result;phase('native-root-terminal')
 assert result=='FINISHED',result
except Exception as err:
 report['error']=type(err).__name__+': '+str(err);save('attempt.json',report)
finally:
 try:client.close()
 except Exception:pass
 # Preserve whatever actually exists, including an incomplete run. The observer uses a new container, with the results volume read-only.
 raw=folder/'raw';raw.mkdir(exist_ok=True)
 inspect_name=prefix+'-result-reader'
 reader_args=['create','--name',inspect_name,'--network','none','--read-only','--user','10003:10003','--cap-drop','ALL','--security-opt','no-new-privileges','--mount','type=volume,src='+case['volume']+',dst=/stored,volume-subpath=oracle-output,readonly','--entrypoint','python',case['server_image'],'-I','-c',"import json,os; p=os.stat('/stored'); print(json.dumps({'device':p.st_dev,'inode':p.st_ino}))"]
 try:
  docker(*reader_args);dirid=json.loads(docker('start','-a',inspect_name));docker('cp',inspect_name+':/stored/.',raw);report['directory_identity']=dirid
  docker('cp',worker+':/opt/v08-native-home/build.json',folder/'native-build.json')
  result_file=raw/spec['result'];ident_file=raw/'native-runtime.json'
  if result_file.is_file():
   rows=json.loads(result_file.read_bytes())['checks'];report['observed_checks']=len(rows);report['failed_checks']={k:v.get('error') for k,v in rows.items() if v.get('passed') is not True};report['passing_checks']=len(rows)-len(report['failed_checks'])
  if result_file.is_file() and ident_file.is_file():
   identity=json.loads(ident_file.read_bytes());assert identity['output_directory_identity']==dirid
   assert set(rows)==set(selection) and all(all(row[t]==selection[k][t] for t in ('dimension','contracts','oracle')) and all(z['choices']==x['choices'] for z,x in zip(prompts.get(k,[]),selection[k]['controller_prompts'])) and len(prompts.get(k,[]))==len(selection[k]['controller_prompts']) for k,row in rows.items())
   build=json.loads((folder/'native-build.json').read_bytes()); assert identity['suite']==suite and identity['executable_sha256']==build['candidate_executor_sha256'] and identity['mapped_private_shared_libraries']==[dict(path='/opt/v08-native-home/bin/libspell_executor313.so',sha256=build['candidate_shared_runtime_sha256'])] and identity['build_manifest']==build and identity['collector_sha256']==digest(adapter.read_bytes())
   ids=sorted({i for row in selection.values() for i in row['contracts']});summary=dict(passed=not report['failed_checks'],suite=suite,dimensional_checks=len(selection),mapped_requirement_ids=ids,distinct_mapped_requirements=len(ids),not_original_spelling_qualification={})
   audit=json.loads(docker('exec',prefix+'-context','python','-I','-c',"import json,sqlite3;d=sqlite3.connect('file:/state/context.sqlite3?mode=ro',uri=True);d.row_factory=sqlite3.Row;print(json.dumps({'members':[dict(r) for r in d.execute('select target_id,instance_id,pid,parent_pid,executable_sha256,state from native_members')],'results':[dict(r) for r in d.execute('select execution_id,native_status from assigned_native_results')],'spent':d.execute('select sum(spent) from workers').fetchone()[0]}))"))
   assert audit['spent']==1 and len(audit['members'])==1 and audit['members'][0]['pid']==identity['pid'] and audit['members'][0]['executable_sha256']==identity['executable_sha256']
   assert audit['results']==[{'execution_id':report['execution_id'],'native_status':'FINISHED'}]
   assert report.get('authoritative_native_status')=='FINISHED'
   report.update(passed=summary["passed"],process_verified=True,oracle=summary,authority=audit,namespace=identity['pid_namespace'],start_ticks=identity['start_ticks'],output_sha256=digest(result_file.read_bytes()),identity_sha256=digest(ident_file.read_bytes()),build_sha256=digest((folder/'native-build.json').read_bytes()))
  else:report['collection_error']='Native oracle or runtime identity file missing'
 except Exception as err:report['collection_error']=type(err).__name__+': '+str(err)
 try:
  (folder/'worker.log').write_bytes(docker('logs',worker))
  st=json.loads(docker('inspect',worker))[0]['State']; report['worker_state']={k:st[k] for k in ('Status','ExitCode','OOMKilled')}
 finally:
  save('attempt.json',report)
  for role in ('worker','gateway','listener','context'):
   try: subprocess.run(['docker','stop','--timeout','3',prefix+'-'+role],capture_output=True,timeout=24)
   except subprocess.TimeoutExpired: report.setdefault('teardown_timeouts',[]).append(role)
 report['finished']=stamp();save('attempt.json',report)
 print(suite,{k:v for k,v in report.items() if k in ('passed','error','collection_error','observed_checks','passing_checks','authoritative_native_status')},flush=True)

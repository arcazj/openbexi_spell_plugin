import os,sys
os.chdir('/workspace/native-language-results')
sys.path.insert(0,'/source')
import files_contracts
import v08_native_language_batch as collector
collector.SPECS=(*collector.SPECS,{'name':'fileswhole','files':['files_contracts.py']})
collector.write_runtime_identity('fileswhole')

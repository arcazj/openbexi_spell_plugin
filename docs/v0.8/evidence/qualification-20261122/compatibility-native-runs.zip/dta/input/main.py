import os
import sys
os.chdir('/workspace/native-language-results')
sys.path.insert(0,'/source')
os.environ['DTA_GROUPS']='mapping'
import dta_contracts
import v08_native_language_batch as observer
observer.SPECS=(*observer.SPECS, {'name':'dta','files':['dta_contracts.py']})
observer.write_runtime_identity('dta')

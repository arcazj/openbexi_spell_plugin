import json,os,sys
os.chdir('/workspace/native-language-results')
sys.path.insert(0,'/source')
import obs_contracts,obs_selected
from pathlib import Path
Path('cases.json').write_text(json.dumps(obs_selected.SOURCES))
obs_contracts.run()
import v08_native_language_batch as observer
observer.SPECS=(*observer.SPECS, {'name':'obs','files':['obs_contracts.py','obs_selected.py']})
observer.write_runtime_identity('obs')

"""Read the retained simulator volume with no network, no write access, and no credentials."""
import base64,gzip,hashlib,json,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent
read_sql="""import base64,hashlib,json,sqlite3,sys
sys.path.insert(0,'/opt/qualification-simulator')
from dss.packets import decode_packet,decode_tc,decode_tm
con=sqlite3.connect('file:/state/dss.sqlite3?mode=ro',uri=True);con.row_factory=sqlite3.Row
rows=[]
for row in con.execute('select id,topic,epoch,sequence,packet from packets order by id'):
 raw=bytes(row['packet']); packet=decode_packet(raw); body=packet.body; assert body['satellite_id']=='GENERIC'; rows.append(dict(id=row['id'],topic=row['topic'],epoch=row['epoch'],sequence=row['sequence'],sha256=hashlib.sha256(raw).hexdigest(),base64=base64.b64encode(raw).decode()))
commands=[]
for row in con.execute('select rowid,raw_tc from operations order by rowid'):
 raw=bytes(row['raw_tc']);body=decode_tc(raw);assert body['satellite_id']=='GENERIC';commands.append(dict(rowid=row['rowid'],sha256=hashlib.sha256(raw).hexdigest(),base64=base64.b64encode(raw).decode()))
print(json.dumps(dict(packets=rows,commands=commands),separators=(',',':')))
"""
for suite,name in [('obs','obsd'),('obs','obse'),('obs','obsf'),('cmd','cmda'),('cmd','cmdb'),('probe','probea'),('limits','limitsa')]:
 f=w/suite/name;case=json.loads((f/'case.json').read_bytes()); raw=subprocess.check_output(['docker','run','--rm','--network','none','--read-only','--user','10003:10003','--cap-drop','ALL','--security-opt','no-new-privileges','--mount','type=volume,src='+case['volume']+',dst=/state,volume-subpath=dss-state,readonly','--entrypoint','python',case['simulator_image'],'-I','-c',read_sql]); out=f/'binary-packets.json.gz';out.write_bytes(gzip.compress(raw,mtime=0)); ledger=json.loads((f/'simulator-ledger.json').read_bytes()); current=json.loads(raw);assert [{k:x[k] for k in ('id','topic','sequence','sha256')} for x in current['packets']]==ledger['packets'];assert [(r['rowid'],r['sha256']) for r in current['commands']]==[(r['rowid'],r['sha256']) for r in ledger['operations']];print(suite,name,len(current['packets']),len(current['commands']),out.stat().st_size,flush=True)

import sys,subprocess
from pathlib import Path
base=Path(__file__).resolve().parent
for suite,name in [(sys.argv[1],sys.argv[2])]:
 case=base/suite
 subprocess.run([sys.executable,case/'start_case_final.py',name],cwd=case,check=True,timeout=120,stdout=subprocess.DEVNULL)
 subprocess.run(['F:/openbexi-builds/qualification-20261122/windows/canonical-01/venv/Scripts/python.exe','-I',base/'run_generic_updated_oracle.py',suite,name],cwd=base,check=True,timeout=520)

import os
import sys
os.chdir('/workspace/native-language-results')
sys.path.insert(0, '/source')
from v08_native_language_batch import write_runtime_identity
import data_contracts
write_runtime_identity('data')

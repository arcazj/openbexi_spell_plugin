import sys,threading
from pathlib import Path
sys.path.insert(0,'/opt/qualification-simulator')
from dss.local import create_servers
runtime,tcp,http=create_servers('/state/dss.sqlite3',8085,http_listen='127.0.0.1')
assert tcp.server_address[0]==http.server_address[0]=='127.0.0.1'
threading.Thread(target=tcp.serve_forever,daemon=True).start()
Path('/state/tcp-port').write_text(str(tcp.server_address[1]))
http.serve_forever(poll_interval=.1)

import json,os,sys
os.chdir('/workspace/native-language-results')
sys.path.insert(0,'/source')
import cmd_contracts,cmd_selected
from pathlib import Path
Path('cases.json').write_text(json.dumps(cmd_selected.SOURCES))
cmd_contracts.run()
import v08_native_language_batch as observer
observer.SPECS=(*observer.SPECS, {'name':'cmd','files':['cmd_contracts.py','cmd_selected.py']})
observer.write_runtime_identity('cmd')

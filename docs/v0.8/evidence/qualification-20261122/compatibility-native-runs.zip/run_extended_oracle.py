from datetime import datetime,timezone
import hashlib,importlib.metadata,importlib.util,json,os,subprocess,sys,time,uuid
from pathlib import Path
from openbexi_runtime import spell_server_client as client_module
from openbexi_runtime.spell_server_client import SpellServerClient
root=Path('C:/projects/openbexi_spell_plugin');base=Path(__file__).resolve().parent
suite,name=sys.argv[1:3];folder=base/suite/name; case=json.loads((folder/'case.json').read_bytes()); prefix=case['prefix']; worker=prefix+'-worker'
digest=lambda b:hashlib.sha256(b).hexdigest()
def docker(*cmd):
 p=subprocess.run(['docker',*map(str,cmd)],capture_output=True,timeout=30)
 p.check_returncode();return p.stdout
def save(n,v): (folder/n).write_bytes((json.dumps(v,indent=2)+'\n').encode())
def stamp():return datetime.now(timezone.utc).isoformat()
def poll(func,seconds):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  answer=func()
  if answer:return answer
  time.sleep(.35)
 raise TimeoutError('Host observation deadline expired')
report={'suite':suite,'case':name,'started':stamp(),'worker_image':case['worker_image'],'server_image':case['server_image'],'snapshot_sha256':case['source_sha256'],'snapshot_git':case['revision'],'ide_client_sha256':digest(Path(client_module.__file__).read_bytes()),'ide_version':importlib.metadata.version('openbexi-ide'),'passed':False,'phases':[]}
assert report['ide_client_sha256']=='1ed509d14d0f30d92c40f3aa5cec3ed4979c8a009919621b93cc83bb989c989d'
assert report['worker_image']=='sha256:de617ca4c3e0d2550bd639c201182f3f36ee21de6d7fd232e17fead8a47e47f3'
assert report['server_image']=='sha256:6189fc60d20bcfd14ae40f10010fcd2cc0c79a9ac70da3118c05c8e2c5dd6583'
adapter=root/'docs/v0.8/evidence/qualification-20261122/compatibility-admitted-oracle.py'; assert digest(adapter.read_bytes())=='c59f7551abca31f105299241af24ac6d5084104e7f297526f5bc415ecbab8bd8'
sp=importlib.util.spec_from_file_location('arch',adapter);arch=importlib.util.module_from_spec(sp);sp.loader.exec_module(arch)
extra=None
if suite in ('files','common'):
 sx=importlib.util.spec_from_file_location('extra',root/'conformance/deployed_language_cases.py');extra=importlib.util.module_from_spec(sx);sx.loader.exec_module(extra)
 spec={'name':suite,'result':suite+'-results.json'}
else:spec=next(x for x in arch.SPECS if x['name']==suite)
arch.protected_inputs(root); key=lambda:str(uuid.uuid4())
client=SpellServerClient.from_config(folder/'alice/connection.json')
def phase(n): report['phases'].append({'phase':n,'utc':stamp()});save('attempt.json',report)
try:
 phase('catalog'); procs=client.read('A','procedures')['procedures'];assert len(procs)==1
 proc=procs[0];assert proc['runtime_image']==case['worker_image'] and proc['source_sha256']==case['source_sha256'] and proc['source_revision']==case['revision']
 cid=client.authority('A','session.open',{},key=key())['connection_id']; inputs={n:proc[n] for n in ('procedure_id','source_revision','source_sha256','runtime_image','driver_binding')}
 reservation=client.authority('A','execution.reserve',dict(inputs,connection_id=cid),key=key());eid=reservation['id'];report['execution_id']=eid; assert client.remember_controller('A',reservation)
 phase('reserved')
 admitted=client.launch('A',eid,key=key());assert admitted['execution_id']==eid and admitted['state']=='ADMITTED';report['launch_receipt']=admitted; phase('admitted')
 def current():return next(v for v in client.read('A','executions')['executions'] if v['id']==eid)
 poll(lambda:current().get('native_root_registered'),35);phase('native-root-registered')
 cmd=client.command('A',eid,'CMD_RUN',key=key());report['run_status']=cmd.get('state',cmd.get('status'));phase('run-command-accepted')
 result=poll(lambda:current().get('native_root_result'),140);report['authoritative_native_status']=result;phase('native-root-terminal')
 assert result=='FINISHED',result
except Exception as err:
 report['error']=type(err).__name__+': '+str(err)
finally:
 try:client.close()
 except Exception:pass
 # Preserve whatever actually exists, including an incomplete run. The observer uses a new container, with the results volume read-only.
 raw=folder/'raw';raw.mkdir(exist_ok=True)
 inspect_name=prefix+'-result-reader'
 reader_args=['create','--name',inspect_name,'--network','none','--read-only','--user','10003:10003','--cap-drop','ALL','--security-opt','no-new-privileges','--mount','type=volume,src='+case['volume']+',dst=/stored,volume-subpath=oracle-output,readonly','--entrypoint','python',case['server_image'],'-I','-c',"import json,os; p=os.stat('/stored'); print(json.dumps({'device':p.st_dev,'inode':p.st_ino}))"]
 try:
  docker(*reader_args);dirid=json.loads(docker('start','-a',inspect_name));docker('cp',inspect_name+':/stored/.',raw);report['directory_identity']=dirid
  docker('cp',worker+':/opt/v08-native-home/build.json',folder/'native-build.json')
  result_file=raw/spec['result'];ident_file=raw/'native-runtime.json'
  if result_file.is_file():
   rows=json.loads(result_file.read_bytes()).get('checks',{});report['observed_checks']=len(rows);report['failed_checks']={k:v.get('error') for k,v in rows.items() if v.get('passed') is not True};report['passing_checks']=len(rows)-len(report['failed_checks'])
  if result_file.is_file() and ident_file.is_file():
   identity=json.loads(ident_file.read_bytes());assert identity['output_directory_identity']==dirid
   summary=(extra.validate(root,suite,json.loads(result_file.read_bytes()),identity,json.loads((folder/'native-build.json').read_bytes()),digest(adapter.read_bytes())) if extra else arch.validate_result(json.loads(result_file.read_bytes()),identity,json.loads((folder/'native-build.json').read_bytes()),root,spec))
   audit=json.loads(docker('exec',prefix+'-context','python','-I','-c',"import json,sqlite3;d=sqlite3.connect('file:/state/context.sqlite3?mode=ro',uri=True);d.row_factory=sqlite3.Row;print(json.dumps({'members':[dict(r) for r in d.execute('select target_id,instance_id,pid,parent_pid,executable_sha256,state from native_members')],'results':[dict(r) for r in d.execute('select execution_id,native_status from assigned_native_results')],'spent':d.execute('select sum(spent) from workers').fetchone()[0]}))"))
   assert audit['spent']==1 and len(audit['members'])==1 and audit['members'][0]['pid']==identity['pid'] and audit['members'][0]['executable_sha256']==identity['executable_sha256']
   assert audit['results']==[{'execution_id':report['execution_id'],'native_status':'FINISHED'}]
   assert report.get('authoritative_native_status')=='FINISHED'
   report.update(passed=True,oracle=summary,authority=audit,namespace=identity['pid_namespace'],start_ticks=identity['start_ticks'],output_sha256=digest(result_file.read_bytes()),identity_sha256=digest(ident_file.read_bytes()),build_sha256=digest((folder/'native-build.json').read_bytes()))
  else:report['collection_error']='Native oracle or runtime identity file missing'
 except Exception as err:report['collection_error']=type(err).__name__+': '+str(err)
 try:
  (folder/'worker.log').write_bytes(docker('logs',worker))
  st=json.loads(docker('inspect',worker))[0]['State']; report['worker_state']={k:st[k] for k in ('Status','ExitCode','OOMKilled')}
 finally:
  for role in ('worker','gateway','listener','context'):
   subprocess.run(['docker','stop','--timeout','3',prefix+'-'+role],capture_output=True,timeout=24)
 report['finished']=stamp();save('attempt.json',report)
 print(suite,{k:v for k,v in report.items() if k in ('passed','error','collection_error','observed_checks','passing_checks','authoritative_native_status')},flush=True)

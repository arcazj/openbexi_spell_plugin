import argparse
import json
import re
import socket
import subprocess
import time
from pathlib import Path
from importlib.util import spec_from_file_location, module_from_spec

base=Path(__file__).parent.resolve()
parser=argparse.ArgumentParser()
parser.add_argument("name")
args=parser.parse_args()
assert re.fullmatch("[a-z0-9]+",args.name)
name="obx-compat-"+args.name
work=base/args.name
work.mkdir(mode=0o700,exist_ok=True)
assert not (work/"case.json").exists()
def docker(*args):
    return subprocess.check_output(["docker",*map(str,args)],text=True).strip()
volume=name+"-case"
docker("volume","create",volume)
edge,service,worker_net=(name+"-"+role for role in ("edge","service","private"))
for index,network in enumerate((edge,service,worker_net)):
    if subprocess.run(["docker","network","inspect",network],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0:
        old=json.loads(docker("network","inspect",network))[0]
        assert old["Name"]==network and old["Internal"]==(network!=edge) and not old["Containers"]
        continue
    subnet="10.237.199."+str((0+index)*32)+"/27"
    docker("network","create","--subnet",subnet,*(["--internal"] if network!=edge else []),network)
images={"runtime":"sha256:b96d56321543bea4818529c0332aa8ced874751a2ab972f02a78213977c1e115","server":"sha256:6324fa788e5b2a28e3f89e8e499a13b711c2d7b3232db10ea6302ddb08e84e16"}
for value in images.values():
    assert docker("image","inspect","--format","{{.Id}}",value)==value
with socket.socket() as sock:
    sock.bind(("127.0.0.1",0))
    port=sock.getsockname()[1]
setup=name+"-setup"
docker("create","--name",setup,"--network","none","--entrypoint","python","-e","WORKER_IMAGE="+images["runtime"],"-e","PUBLIC_PORT="+str(port),
       "--mount",f"type=volume,src={volume},dst=/case",images["server"],"-I","/setup.py")
docker("cp",base/"setup_case.py",setup+":/setup.py")
docker("cp",base/"input",setup+":/input")
subprocess.run(["docker","start","--attach",setup],check=True)
docker("cp",setup+":/case/case.json",work/"case.json")
for subject in ("alice","observer"):
    private=work/subject
    private.mkdir(mode=0o700)
    docker("cp",setup+":/case/"+subject+"/.",private)
docker("rm",setup)
def mount(src,dst,ro=True):
    return ["--mount",f"type=volume,src={volume},dst={dst},volume-subpath={src}"+(",readonly" if ro else "")]
dss_image="sha256:da2607edf9eccfa915805c7b84054017b63616fc7222992b44ef2dd9d526b8e9"
assert docker("image","inspect","--format","{{.Id}}",dss_image)==dss_image
dss=name+"-simulator"
observer=name+"-fixture"
fixed=["--read-only","--user","10003:10003","--cap-drop","ALL","--security-opt","no-new-privileges","--pids-limit","64"]
docker("create","--name",dss,"--network",service,"--network-alias","context",*fixed,*mount("dss-state","/state",False),"--entrypoint","python",dss_image,"-I","-c",(base/"simulate.py").read_text())
docker("network","connect","--alias","context",worker_net,dss)
docker("start",dss)
for _ in range(30):
    checked=subprocess.run(["docker","exec",dss,"cat","/state/tcp-port"],capture_output=True,text=True)
    if checked.returncode==0: break
    time.sleep(.15)
else: raise RuntimeError("Simulator did not report loopback endpoint: "+docker("logs",dss))
tcp_port=int(checked.stdout);assert 1<=tcp_port<=65535
edit="import json,sys;from pathlib import Path;p=Path('/credentials/config.json');config=json.loads(p.read_bytes());config['native_driver']['tcp'][1]=int(sys.argv[1]);p.write_text(json.dumps(config))"
docker("run","--rm","--network","none","--read-only","--entrypoint","python",*mount("context","/credentials",False),images['server'],"-I","-c",edit,tcp_port)
docker("create","--name",observer,"--network","container:"+dss,*fixed,*mount("oracle-output","/work",False),"--entrypoint","python",dss_image,"-I","-c",(base/"observe.py").read_text())
docker("start",observer)
for role,network in (("context",service),("listener",edge),("gateway",edge),("worker",worker_net)):
    cnt=name+"-"+role
    common=["--name",cnt,"--network",network,"--network-alias",role,"--init","--read-only","--user","10003:10003","--cap-drop","ALL","--security-opt","no-new-privileges","--pids-limit","256",*mount(role,"/credentials")]
    if role=="worker":
        command=[*common,"--memory","1536m","--memory-swap","1536m","--cpus","2","--tmpfs","/tmp:rw,nosuid,nodev,size=128m",
                 "--tmpfs","/workspace:rw,nosuid,nodev,size=16m,mode=0700,uid=10003,gid=10003","--env","OPENBEXI_V08_AUDIT_ROOT=/audit",*mount("audit","/audit",False),
                 *mount("snapshot","/source"),*mount("oracle-output","/workspace/native-language-results",False),images["runtime"]]
    else:
        if role=="context":
            pos=common.index("--network"); common[pos+1]="container:"+dss
            pos=common.index("--network-alias"); del common[pos:pos+2]
            common+=[*mount("git","/git"),*mount("state","/state",False)]
        if role=="gateway":
            common+=["--publish",f"127.0.0.1:{port}:9443"]
        command=[*common,"--tmpfs","/tmp:rw,nosuid,nodev,size=8m",*(["--entrypoint","python",dss_image,"-I","-c","import runpy,sys;sys.path.insert(0,'/opt/qualification-simulator');runpy.run_module('openbexi_spell_dss.context_server',run_name='__main__')"] if role=="context" else [images["server"]]),role,"--config","/credentials/config.json"]
    docker("create",*command)
    if role=="listener":
        docker("network","connect","--alias","listener",service,cnt)
    docker("start",cnt)
    for i in range(50):
        status=docker("inspect","--format","{{.State.Status}}",cnt)
        if status!="running":
            raise RuntimeError(role+" exited: "+docker("logs",cnt))
        if role=="worker" or '"port": 9443' in docker("logs",cnt):
            break
        time.sleep(0.1)
    else:
        raise TimeoutError(role+" did not listen")
cfg=json.loads((work/"case.json").read_text())
cfg.update(prefix=name,server_image=images["server"],worker_image=images["runtime"],networks=[edge,service,worker_net],volume=volume,worker_memory_mib=1536,context_image=dss_image,simulator_image=dss_image,simulator_http="127.0.0.1:8085",simulator_tcp="127.0.0.1:"+str(tcp_port))
(work/"case.json").write_text(json.dumps(cfg,indent=2)+"\n")
print(json.dumps(cfg))

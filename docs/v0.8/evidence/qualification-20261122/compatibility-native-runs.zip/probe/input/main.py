import json,os,sys
from pathlib import Path
os.chdir('/workspace/native-language-results')
sys.path.insert(0,'/source')
import cmd_contracts,probe_selected
rows={}
for key,source in probe_selected.SOURCES.items():
    Path('current.json').write_text(json.dumps({'check':key}))
    cmd_contracts.fixture('feed',value=True)
    cmd_contracts.fixture('observe')
    try:
        exec(compile(source,'retained bounded qualification','exec'),{})
        result={'passed':True}
    except Exception as error:
        result={'passed':False,'error':type(error).__name__+': '+str(error)}
    cmd_contracts.fixture('observe')
    rows[key]=dict(result,source=source,expected_prompts=[])
    Path('checks.json').write_text(json.dumps(rows,indent=2))
import v08_native_language_batch as observer
observer.SPECS=(*observer.SPECS,{'name':'probe','files':['cmd_contracts.py','probe_selected.py']})
observer.write_runtime_identity('probe')

import sys,subprocess
from pathlib import Path
base=Path(__file__).resolve().parent
for suite,name in [('dta','dtaa')]:
 case=base/suite
 subprocess.run([sys.executable,case/'start_case.py',name],cwd=case,check=True,timeout=120,stdout=subprocess.DEVNULL)
 subprocess.run(['F:/openbexi-builds/qualification-20261122/windows/canonical-01/venv/Scripts/python.exe','-I',base/'run_dta_oracle.py',suite,name],cwd=base,check=True,timeout=260)

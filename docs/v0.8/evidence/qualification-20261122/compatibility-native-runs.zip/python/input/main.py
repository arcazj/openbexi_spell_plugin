import os
import sys
os.chdir('/workspace/native-language-results')
sys.path.insert(0, '/source')
from v08_native_language_batch import write_runtime_identity
import python_contracts
write_runtime_identity('python')

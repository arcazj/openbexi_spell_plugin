"""Provision one private, loopback-only qualification stack. Runs once inside Linux."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import ssl
import subprocess
from openbexi_spell_server.contracts import digest
from openbexi_spell_server.snapshots import git_manifest

root = Path("/case")
roles = ("context", "listener", "gateway", "worker", "alice", "observer")
for name in (*roles, "snapshot","audit","state","git","oracle-output"):
    (root / name).mkdir(mode=0o755)

private = Path("/tmp/pki")
private.mkdir(mode=0o700)
def openssl(*args):
    subprocess.run(["openssl",*args],cwd=private,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
def write(path,obj):
    path.write_text(json.dumps(obj,indent=2)+"\n")
openssl("req","-x509","-newkey","rsa:2048","-nodes","-days","1","-subj","/CN=public-launch-test-ca",
        "-addext","basicConstraints=critical,CA:TRUE","-addext","keyUsage=critical,keyCertSign,cRLSign",
        "-keyout","ca.key","-out","ca.pem")
(private/"ext").write_text("subjectAltName=DNS:localhost,DNS:context,DNS:listener,DNS:gateway,IP:127.0.0.1\nbasicConstraints=critical,CA:FALSE\nkeyUsage=critical,digitalSignature,keyEncipherment\nextendedKeyUsage=serverAuth,clientAuth\n")
pins = {}
for name in roles:
    d = root/name
    openssl("req","-newkey","rsa:2048","-nodes","-subj","/CN="+name,"-keyout",d/"tls.key","-out",name+".csr")
    openssl("x509","-req","-in",name+".csr","-CA","ca.pem","-CAkey","ca.key","-CAcreateserial","-days","1","-extfile","ext","-out",d/"tls.pem")
    shutil.copyfile(private/"ca.pem",d/"ca.pem")
    pins[name]=hashlib.sha256(ssl.PEM_cert_to_DER_cert((d/"tls.pem").read_text())).hexdigest()
    (d/"tls.key").chmod(0o400)
    os.chown(d/"tls.key",10003,10003)

gitdir=root/"git"
def git(*args):
    return subprocess.check_output(["git","-C",gitdir,*args],text=True, env=dict(os.environ,GIT_AUTHOR_DATE="2026-11-22T00:00:00Z",GIT_COMMITTER_DATE="2026-11-22T00:00:00Z")).strip()
git("init","-q")
procedure=b"import time\ntime.sleep(1.2)\nwith open('/workspace/approved-procedure-completed', 'w') as output:\n    output.write('public launch complete\\n')\n"
inputs=Path("/input")
procedure=(inputs/"main.py").read_bytes()
for oracle in sorted(inputs.glob("*.py")):
    (gitdir/oracle.name).write_bytes(oracle.read_bytes())
git("add",".")
git("-c","user.name=Qualification","-c","user.email=test@example.invalid","-c","commit.gpgsign=false","commit","-qm","Approved public launch fixture")
revision=git("rev-parse","HEAD")
manifest=git_manifest(gitdir,revision,"main.py")
checksum=digest(manifest)
for oracle in sorted(inputs.glob("*.py")):
    staging=root/"snapshot"/oracle.name
    staging.write_bytes(oracle.read_bytes())
    staging.chmod(0o644)
image=os.environ["WORKER_IMAGE"]
port=int(os.environ["PUBLIC_PORT"])
tls=dict(ca="/credentials/ca.pem", certificate="/credentials/tls.pem", key="/credentials/tls.key")
common=dict(tls, bind="0.0.0.0",port=9443,max_handlers=24)
all_permissions=["context:read","execution:read","execution:start","execution:control","execution:request_control"]
public={"url":f"https://127.0.0.1:{port}","fingerprint":pins["gateway"],"ca":"ca.pem","certificate":"tls.pem","key":"tls.key"}
roles_subjects=["alice","observer"]
for name in roles_subjects:
    write(root/name/"connection.json",public)
entry=dict(repository="/git",revision=revision,entrypoint="main.py",runtime_image=image,driver_binding="context-audit",aliases=[])
context=dict(common,allowed_hosts=["context:9443"],context_id="A",state_directory="/state",listener_fingerprint=pins["listener"],
    subjects={"alice":all_permissions,"observer":["context:read","execution:read"]},worker_slots={"one":"instance-1"},
    worker_credentials={"profile":"single-host-preflight","identities":{pins["worker"]:{"slot":"one","incarnation":"instance-1"}}},
    approved_sources={"approved-main":entry},worker_launch="assigned-single-use",native_children="admission-only",
    native_controls="run-journal",native_commands="owner-queue",native_prompts="owner-reply-candidate")
listener=dict(common,allowed_hosts=["listener:9443"],edge_fingerprint=pins["gateway"],identities={pins[n]:n for n in roles_subjects},
    scopes={n:["A"] for n in roles_subjects},contexts={"A":{"url":"https://context:9443","fingerprint":pins["context"]}},
    native_command_contexts=["A"],native_launch_contexts=["A"])
gateway=dict(common,allowed_hosts=[f"localhost:{port}",f"127.0.0.1:{port}"],listener_url="https://listener:9443",
    listener_fingerprint=pins["listener"],clients=[pins[n] for n in roles_subjects])
worker=dict(assigned=dict(tls,context_url="https://context:9443",context_fingerprint=pins["context"],context_id="A",
    worker_slot="one",worker_incarnation="instance-1",runtime_image=image,snapshots={checksum:"/source"}),native_prompts=True)
for name,cfg in (("context",context),("listener",listener),("gateway",gateway),("worker",worker)):
    write(root/name/"config.json",cfg)
for name in ("audit","state","oracle-output"):
    (root/name).chmod(0o700)
    os.chown(root/name,10003,10003)
# The read-only Git tree is pinned at the immutable commit. Its exact metadata is
# readable to the service running as the same unprivileged uid.
for current,dirs,files in os.walk(gitdir):
    os.chown(current,10003,10003)
    for file in files:
        os.chown(Path(current)/file,10003,10003)
write(root/"case.json",dict(revision=revision,source_sha256=checksum,procedure_sha256=hashlib.sha256(procedure).hexdigest(),image=image,
    entrypoint="main.py",driver_binding="context-audit",public_port=port))

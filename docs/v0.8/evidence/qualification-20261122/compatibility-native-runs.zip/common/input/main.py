import os
import sys
os.chdir('/workspace/native-language-results')
sys.path.insert(0,'/source')
from deployed_language_cases import run
run('common')

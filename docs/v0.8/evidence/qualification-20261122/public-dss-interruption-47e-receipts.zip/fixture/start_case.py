"""Set up a single private two-worker delivery fixture for an interrupted simulated read."""
import json
from pathlib import Path
import re
import socket
import subprocess
import sys
import time

tools = Path(__file__).resolve().parent
scope = sys.argv[1]
assert re.fullmatch(r"dssfault47[a-z]?", scope)
subnet = int(sys.argv[2])
assert 60 <= subnet <= 79
prefix = "obx-public-launch-" + scope
root = tools.parent / scope
root.mkdir(mode=0o700)
core = "sha256:b1b46dcda1f8db45889f6a145d2125362bbc04c41ded6e956ea99ca1ea61f968"
gateway = "sha256:f500c700cb5714a2040064a1a9bc93e3e86ae086cdc28dc65d363161af3ba94e"
worker = "sha256:489ff81aaa52ecbf09b4281499ed00f22fdd8b19e51e133a0202f2bbb6a40413"
provisioner = "sha256:a897af70ab6edf5aa6c8d05681111231f6c6b715e5da2f060bab02f149a91bbd"
driver_image = "sha256:37b524ee076c90c52f813b08eaba46c01a95af86cc60b7d82694c7293436d8b6"
label = "openbexi.qualification.run=" + scope

def docker(*args):
    return subprocess.check_output(["docker", *map(str, args)], text=True).strip()

def mount(src, dest, ro=True):
    spec = f"type=volume,src={volume},dst={dest},volume-subpath={src},volume-nocopy"
    return ["--mount", spec + (",readonly" if ro else "")]

for image in (core, gateway, worker, provisioner, driver_image):
    assert docker("image", "inspect", "--format", "{{.Id}}", image) == image
volume = prefix + "-case"
edge, service, one, two = [prefix + "-" + r for r in ("edge", "service", "one", "two")]
docker("volume", "create", "--label", label, volume)
for index, network in enumerate((edge, service, one, two)):
    docker("network", "create", "--label", label, "--subnet", f"198.19.{subnet}.{index * 32}/27",
           *([] if network == edge else ["--internal"]), network)
with socket.socket() as sock:
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
setup = prefix + "-setup"
docker("create", "--name", setup, "--label", label, "--user", "0:0", "--network", "none", "--entrypoint", "python",
       "-e", "WORKER_IMAGE=" + worker, "-e", f"PUBLIC_PORT={port}", "-e", "SERVICE_UID=65532",
       "--mount", f"type=volume,src={volume},dst=/case", provisioner, "-I", "/setup.py")
for src, dest in (("setup_case.py", "/setup.py"), ("sensor.py","/qualification-procedure.py"), ("witness.py","/qualification-child.py")):
    docker("cp", tools / src, setup + ":" + dest)
docker("start", "--attach", setup)
docker("cp", setup + ":/case/case.json", root / "case.json")
for user in ("alice", "observer"):
    (root/user).mkdir(mode=0o700)
    docker("cp", setup + ":/case/" + user + "/.", root/user)
docker("rm", setup)
ids = {}
secure = ["--label", label, "--init", "--read-only", "--cap-drop", "ALL", "--security-opt", "no-new-privileges", "--pids-limit", "256"]
tmp = ["--tmpfs", "/tmp:rw,nosuid,nodev,size=8m"]
def create(role, *params):
    name = prefix + "-" + role
    ids[role] = docker("create", "--name", name, *secure, *params)
    return name

sim = create("simulator", "--network", service, "--network-alias", "context", "--user", "10003:10003", *tmp,
             *mount("dss-state","/state",False), "--entrypoint", "python", driver_image, "-I", "-c", (tools/"simulate.py").read_text())
for network in (one, two):
    docker("network","connect","--alias","context",network,sim)
docker("start",sim)
for attempt in range(50):
    p=subprocess.run(["docker","exec",sim,"cat","/state/tcp-port"],capture_output=True,text=True)
    if p.returncode==0:break
    time.sleep(.1)
else:raise RuntimeError("DSS startup failed: "+docker("logs",sim))
tcp_port=int(p.stdout)
assert 0<tcp_port<65536
edit=("import json,sys;from pathlib import Path;p=Path('/cred/config.json');x=json.loads(p.read_bytes());"
      "assert x['native_driver']['commands']==[] and x['native_driver']['telemetry']==['TM.POWER.BUS_VOLTAGE'];"
      "x['native_driver']['tcp'][1]=int(sys.argv[1]);p.write_text(json.dumps(x))")
docker("run","--rm","--network","none","--read-only","--user","0:0","--cap-drop","ALL","--entrypoint","python",
       *mount("context","/cred",False),provisioner,"-I","-c",edit,tcp_port)
ctx = create("context","--network","container:"+sim,"--user","65532:65532",*tmp,*mount("context","/credentials"),
             *mount("git","/git"),*mount("state","/state",False),"--entrypoint","python",driver_image,"-I","-c",
             "import runpy,sys;sys.path.insert(0,'/opt/qualification-simulator');runpy.run_module('openbexi_spell_dss.context_server',run_name='__main__')",
             "context","--config","/credentials/config.json")
listener=create("listener","--network",edge,"--network-alias","listener","--user","65532:65532",*tmp,*mount("listener","/credentials"),
                core,"listener","--config","/credentials/config.json")
docker("network","connect","--alias","listener",service,listener)
gw=create("gateway","--network",edge,"--network-alias","gateway","--user","65532:65532",*tmp,*mount("gateway","/credentials"),
          "--publish",f"127.0.0.1:{port}:9443",gateway,"gateway","--config","/credentials/config.json")
operator=create("marker","--network","none","--user","10003:10003",*tmp,*mount("signals","/signals",False),
                *mount("audit","/one"),*mount("audit-witness","/two"),"--entrypoint","python",core,"-I","-c","import time;time.sleep(2400)")
docker("start",operator)
for cnt in (ctx,listener,gw):
    docker("start",cnt)
    for i in range(50):
        if docker("inspect","--format","{{.State.Status}}",cnt)!="running":
            raise RuntimeError(cnt+" failed to serve "+docker("logs",cnt))
        if '"port": 9443' in docker("logs",cnt):break
        time.sleep(.1)
    else:raise TimeoutError(cnt+" did not listen")
for role,network,audit in (("worker",one,"audit"),("worker2",two,"audit-witness")):
    cnt=create(role,"--network",network,"--user","10003:10003","--memory","1536m","--memory-swap","1536m","--cpus","2",
               "--tmpfs","/tmp:rw,nosuid,nodev,size=128m","--tmpfs","/workspace:rw,nosuid,nodev,size=16m,mode=0700,uid=10003,gid=10003",
               "--env","OPENBEXI_V08_AUDIT_ROOT=/audit",*mount(role,"/credentials"),*mount(audit,"/audit",False),*mount("snapshot","/source"),
               *mount("signals","/signals"),worker)
    docker("start",cnt)
cfg=json.loads((root/"case.json").read_bytes())
cfg.update(prefix=prefix,role_ids=ids,networks=[edge,service,one,two],images=dict(gateway=gateway,listener=core,
        context=driver_image,simulator=driver_image,worker=worker,worker2=worker,marker=core),volume=volume,simulator_tcp_port=tcp_port)
(root/"case.json").write_text(json.dumps(cfg,indent=2)+"\n",newline="\n")
print("Prepared",scope,"and two single-use native workers",flush=True)

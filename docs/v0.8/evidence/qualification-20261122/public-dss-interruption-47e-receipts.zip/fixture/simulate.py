from pathlib import Path
import sys
import threading
import time

sys.path.insert(0, "/opt/qualification-simulator")
from dss.local import create_servers

runtime, tcp, http = create_servers("/state/dss.sqlite3", 8085, http_listen="127.0.0.1")
assert tcp.server_address[0] == http.server_address[0] == "127.0.0.1"
runtime.engine.advance(1)
def advance_test_clock():
    while not runtime.stop_event.wait(0.5):
        runtime.engine.advance(1)
threading.Thread(target=advance_test_clock, daemon=True).start()
threading.Thread(target=tcp.serve_forever, daemon=True).start()
Path("/state/tcp-port").write_text(str(tcp.server_address[1]))
http.serve_forever(poll_interval=0.1)

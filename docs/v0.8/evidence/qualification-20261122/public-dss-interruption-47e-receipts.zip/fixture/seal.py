"""Seal the measured read-only incident and the independent witness evidence."""
import json
from pathlib import Path
import re
import subprocess
import sys
from hashlib import sha256
from zipfile import ZipFile, ZIP_DEFLATED

tools=Path(__file__).resolve().parent
case=Path(sys.argv[1]).resolve()
repo=Path("C:/projects/openbexi_spell_plugin")
receipt=repo/"docs/v0.8/evidence/qualification-20261122/public-dss-interruption-47e.json"
assert not receipt.exists()
data=json.loads((case/"fault.json").read_bytes());assert data["passed"]
cfg=json.loads((case/"case.json").read_bytes());ids=cfg["role_ids"]
build=json.loads((tools/"build.json").read_bytes())
rev=build["source"]
assert rev=="47e0cb376dac1e49e1f6745318c0eb3e43b2ec4d"
assert cfg["images"]["context"]==cfg["images"]["simulator"]==build["runtime"]
def docker(*cmd):
    return subprocess.check_output(["docker",*map(str,cmd)],text=True).strip()
def sha(path):return sha256(path.read_bytes()).hexdigest()
def save(path,obj):path.write_text(json.dumps(obj,indent=2)+"\n",newline="\n")
def source(path):
    return subprocess.check_output(["git","-C",repo,"show",rev+":"+path])
cfg_roles={}
for row in json.loads(docker("inspect",*ids.values())):
    role=next(k for k,v in ids.items() if v==row["Id"])
    assert row["Name"]=="/"+cfg["prefix"]+"-"+role and row["Config"]["Labels"]["openbexi.qualification.run"]==case.name
    cfg_roles[role]={"image":row["Image"],"id":row["Id"],"run_as":row["Config"]["User"],"namespace":row["HostConfig"]["NetworkMode"],
                     "readonly_root":row["HostConfig"]["ReadonlyRootfs"],"capabilities_dropped":row["HostConfig"]["CapDrop"],
                     "no_new_privileges":row["HostConfig"]["SecurityOpt"],"port_bindings":row["HostConfig"]["PortBindings"],
                     "final_status":row["State"]["Status"],"exit_code":row["State"]["ExitCode"]}
    with (case/(role+"-service.log")).open("wb") as log:
        subprocess.run(["docker","logs","--timestamps",ids[role]],check=True,stdout=log,stderr=subprocess.STDOUT)
q = """
import json,sqlite3
db=sqlite3.connect('file:/state/context.sqlite3?mode=ro',uri=True)
def query(s):return [list(r) for r in db.execute(s)]
print(json.dumps({'execution_columns':['procedure_id','slot','start_lifecycle','control_state_after_controller_departed'],
'executions':query('select procedure_id,worker_slot,lifecycle,control_state from executions order by procedure_id'),
'spent_slots':query('select slot,spent from workers order by slot'),'observed_roots':query('select execution_id,native_status from assigned_native_results order by execution_id'),
'driver_states':query('select path,state,count(*) from native_driver_calls group by path,state order by path,state'),
'events':query('select type,count(*) from events group by type order by type')}))
"""
authority=json.loads(docker("exec",ids["context"],"python","-I","-c",q))
assert authority["spent_slots"]==[["one",1],["two",1]] and [r[1] for r in authority["observed_roots"]]==["FINISHED","FINISHED"]
def extract_asrun(role,directory):
    path=docker("exec",ids["marker"],"python","-I","-c","from pathlib import Path;import sys;files=list(Path(sys.argv[1]).glob('*.ASRUN'));assert len(files)==1;print(files[0])","/"+directory)
    dest=case/(role+".ASRUN")
    docker("cp",ids["marker"]+":"+path,dest)
    return {"file":dest.name,"size":dest.stat().st_size,"sha256":sha(dest)}
asruns={role:extract_asrun(role,d) for role,d in (("sensors","one"),("witness","two"))}
details={}
for proc,e in data["executions"].items():
    role=e["worker"]
    logs=[]
    for line in (case/(role+"-service.log")).read_text(errors="replace").splitlines():
        when,sep,raw=line.partition(" ")
        if not sep or not raw.startswith("{"):continue
        row=json.loads(raw)
        if row.get("event") in {"native-ready","native-running","native-finished","native-worker-failed","native-driver-denied","native-terminal-rejected","native-owner-profile-failed"}:
            logs.append(dict(utc=when,**{k:v for k,v in row.items() if k in {"event","execution_id","native_status","hold_retained","native_lifecycle_receipts_settled","status","code","path","error","executor_pid"}}))
    details[proc]=dict(execution_id=e["id"],image_role=role,worker_exit_code=cfg_roles[role]["exit_code"],worker_events=logs,procedure_marker=e["procedure_result"],asrun=asruns[proc])
assert details["sensors"]["worker_exit_code"]==1 and details["witness"]["worker_exit_code"]==0
save(case/"authority-final.json",authority)
save(case/"role-isolation.json",cfg_roles)
save(case/"native-summary.json",details)
all_source=["server/src/openbexi_spell_server/transport.py","host_runtime/python/native.py","host_runtime/python/v08_worker.py",
            "driver_plugin/src/openbexi_spell_dss/context_driver.py","driver_plugin/src/openbexi_spell_dss/fenced_transport.py",
            "driver_plugin/src/openbexi_spell_dss/transport.py","src/dss/local.py","src/dss/server.py"]
source_proof={path:sha256(source(path)).hexdigest() for path in all_source}
bundle=case/"dss-interruption-evidence.zip"
with ZipFile(bundle,"w",compression=ZIP_DEFLATED) as z:
    for name in ["case.json","fault.json","authority-final.json","role-isolation.json","native-summary.json","sensors.ASRUN","witness.ASRUN","preflight-manual-clock.json"]:
        z.write(case/name,"run/"+name)
    for role in ids:
        z.write(case/(role+"-service.log"),"logs/"+role+".log")
    for name in ["build_dss.py","build.json","build.log","image.id","setup_case.py","start_case.py","simulate.py","sensor.py","witness.py","measure.py","seal.py","dss-image/Dockerfile"]:
        z.write(tools/name,"fixture/"+name)
with ZipFile(bundle) as z:assert z.testzip() is None
fail=data["ledger_interrupted"]["failures"][0]
initial=next(x for x in data["ledger_before"]["calls"] if x["path"].endswith("/RefreshItem"))
original=next(x for x in data["ledger_recovered"]["calls"] if x["state"]=="UNCERTAIN")
assert original["request_id"]==fail["request_id"] and original["response_hash"] is None
assert data["ledger_recovered"]==data["ledger_interrupted"]
card={"schema":"openbexi.qualification.private-dss-read-interruption/1","status":"PASS for the bounded local read-interruption and unaffected-worker subcase",
"measured_utc":[data["events"][0]["utc"],data["events"][-1]["utc"]],
"scope":"Two separate single-use native workers on the same Context, with one ordinary GENERIC telemetry reader, one audit-only witness and a pinned mTLS read-only public observer. The fault was a cgroup pause of the dedicated synthetic DSS, followed by unpause of that same container.",
"subjects":{"ide_source":"fadac70d574760cbe21c5e5512a384dddfa36e80","ide_wheel_sha256":"1d68d0a13f85a9e64a084757c6be280cdc2feb77d97027df0d98bfc2ebffb58f",
"spell_source":rev,"server_wheel_sha256":"d39f4c6cc0735fea0c1331724a520658d866faf4548ded7f01802fcab2f6f3e8",
"dss_wheel_sha256":build["dss_wheel_sha256"],"gateway":cfg["images"]["gateway"],"listener_core":cfg["images"]["listener"],
"assigned_worker":cfg["images"]["worker"],"private_dss_context_and_simulator":build["runtime"],
"private_composition":"Canonical core plus the exact DSS driver wheel, 47e src/dss, and grpcio/protobuf copied from the canonical worker. Both private services ran in separate cgroups. The private adapter image was built for this test.",
"installed":build["installed"],"runtime_source_hashes":source_proof,"immutable_test_sources":data["sources"]},
"fixture":{"public_interface":"Windows installed SpellServerClient over loopback pinned-mTLS HTTPS","observer":data["observer"],
"linux_container_pids_during_fault":{r:s["Pid"] for r,s in data["interrupted_container_state"].items() if r!="marker"},
"suspended_roles":[r for r,s in data["interrupted_container_state"].items() if s["Paused"]],
"worker_networks_separate":cfg_roles["worker"]["namespace"]!=cfg_roles["worker2"]["namespace"],
"simulator_endpoint":"private loopback in the Context and DSS shared network namespace",
"public_port_roles":[r for r,s in cfg_roles.items() if s["port_bindings"]],
"driver_permission":data["private_driver"],"clock":"One explicit manual synthetic STEP refreshed the healthy sample before the original reads."},
"observed":{"successful_read":{"native_GetTM_volts":28.0,"request_id":initial["request_id"],"response_sha256":initial["response_hash"]},
"interrupted_read":{"method":original["path"],"request_id":original["request_id"],"payload_sha256":original["payload_hash"],
"states":["ADMITTED","UNCERTAIN"],"persisted_response_sha256":None,"failure_event_sequence":fail["sequence"],
"error_chain":fail["error_chain"],"seconds_from_external_signal_to_first_observation":data["uncertain_seconds_after_signal"],
"native_result":details["sensors"],"public_native_root_result":"FINISHED"},
"unaffected_worker":{"progress_counter_before_pause_during_pause_after_restore":data["observed_witness_ticks"],
"native_result":details["witness"],"public_native_root_result":"FINISHED"},
"observer_views_during_pause":data["observations"]["simulator_paused"],"observer_terminal":data["observations"]["terminal"],
"post_restore_no_replay":{"unchanged_ledger_seconds":data["observation_after_restoration_s"],"driver_states":authority["driver_states"],
"failure_events":len(data["ledger_recovered"]["failures"]),"effect_stage_rows":data["ledger_recovered"]["effect_stages"],
"simulator_commands_executed_before_after":[data["simulator_before"]["commands_executed"],data["simulator_after"]["commands_executed"]],
"same_simulator_epoch":data["simulator_before"]["epoch"]==data["simulator_after"]["epoch"],"spent_worker_slots":authority["spent_slots"]}},
"deadlines":{"native_default_TM_option_seconds":3,"context_max_TM_option_seconds":3,"metadata_handler_admission_seconds":0.25,
"DSS_metadata_HTTP_seconds":3,"worker_to_Context_driver_response_seconds":5,"other_private_RPC_connect_and_response_seconds":2,"absolute_worker_RPC_watchdog_seconds":5,
"interpretation":"The timeout occurred during current_state before telemetry sampling. The external observation includes marker delivery and ledger sampling. All candidate deadlines were unchanged."},
"interpretation":"The source caught DriverException and the original C++ root reported FINISHED. The worker independently classified the driver failure, exited 1, and retained the occupied hold. The other worker finished, reported settled lifecycle receipts, exited 0, and retained its own single-use hold. The authority preserved the failed read identity and disclosed no response.",
"boundary":"Only an ordinary telemetry read and a disposable synthetic DSS interruption were exercised. Lost telecommand acknowledgements, external hardware, Listener loss, and cluster node failure are separate scopes.",
"reproduction":{"dedicated_private_run":case.name,"source_bundle_path":str(bundle).replace(chr(92),"/"),"bundle_sha256":sha(bundle),"bytes":bundle.stat().st_size,
"public_evidence_files":{"measured_run":sha(case/"fault.json"),"private_adapter_recipe":build["recipe_sha256"],"private_wrapper_build":sha(tools/"build.json"),"worker_isolation":sha(case/"role-isolation.json"),"final_readonly_ledger":sha(case/"authority-final.json")}}}
assert card["fixture"]["suspended_roles"]==["simulator"] and card["fixture"]["public_port_roles"]==["gateway"] and card["fixture"]["worker_networks_separate"]
save(receipt,card);print(receipt,sha(receipt));print(bundle,sha(bundle),bundle.stat().st_size)

"""Interrupt only the disposable GENERIC simulator during one original native GetTM."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import traceback
from datetime import datetime, timezone
from uuid import uuid4

from openbexi_runtime.spell_server_client import SpellServerClient

case = Path(sys.argv[1]).resolve()
cfg = json.loads((case / "case.json").read_bytes())
ids = cfg["role_ids"]
assert cfg["prefix"] == "obx-public-launch-" + case.name and case.name.startswith("dssfault47")
report = {"passed":False,"case":case.name,"images":cfg["images"],"sources":{},"executions":{},"events":[],"observations":{}}
def utc():
    return datetime.now(timezone.utc).isoformat()
def save():
    (case/"fault.json").write_text(json.dumps(report,indent=2)+"\n",newline="\n")
def record(event, **fields):
    row={"event":event,"utc":utc(),**fields}
    report["events"].append(row)
    save()
    print(event,flush=True)
def docker(*args):
    p=subprocess.run(["docker",*map(str,args)],text=True,capture_output=True)
    if p.returncode:raise RuntimeError(f"Docker {args[0]} exited {p.returncode}: {p.stderr[:250]}")
    return p.stdout.strip()
def run(role, code, *args):
    return docker("exec",ids[role],"python","-I","-c",code,*args)
def bounded(fn, timeout, label, interval=.1):
    deadline=time.monotonic()+timeout
    while time.monotonic()<deadline:
        x=fn()
        if x:return x
        time.sleep(interval)
    raise TimeoutError(label)
def key():
    return str(uuid4())
def statuses():
    inspected=json.loads(docker("inspect",*ids.values()))
    out={}
    for row in inspected:
        role=next(k for k,v in ids.items() if v==row["Id"])
        assert row["Name"]=="/"+cfg["prefix"]+"-"+role
        assert row["Config"]["Labels"]["openbexi.qualification.run"]==case.name
        assert row["Image"]==cfg["images"][role]
        assert row["HostConfig"]["ReadonlyRootfs"] and row["HostConfig"]["CapDrop"]==["ALL"]
        out[role]={k:row["State"][k] for k in ("Pid","Running","Paused","ExitCode","Status")}
    return out
def marker_file(directory,file):
    return run("marker","from pathlib import Path;import sys;p=Path(sys.argv[1]);print(p.read_text() if p.is_file() else '')",f"/{directory}/{file}")
def marker(file):
    assert file in {"read-second","finish-witness"}
    run("marker","import sys;from pathlib import Path;p=Path('/signals')/sys.argv[1];assert not p.exists();p.touch(exist_ok=False)",file)
def native_events(role):
    text=docker("logs","--timestamps",ids[role]); events=[]
    for line in text.splitlines():
        stamp,sep,data=line.partition(" ")
        if not sep or not data.startswith("{"):continue
        row=json.loads(data)
        if row.get("event") in {"native-ready","native-running","native-finished","native-worker-failed"}:
            events.append(dict(utc=stamp,**{k:v for k,v in row.items() if k in {"event","native_status","execution_id","hold_retained","native_pid","receipts_settled","detail","error_reason"}}))
    return events
db_code="""
import json,sqlite3
db=sqlite3.connect('file:/state/context.sqlite3?mode=ro',uri=True)
db.row_factory=sqlite3.Row
calls=[dict(x) for x in db.execute("SELECT request_id,execution_id,binding,path,payload_hash,state,response_hash FROM native_driver_calls ORDER BY rowid")]
failures=[]
for row in db.execute("SELECT sequence,body FROM events WHERE type='NATIVE_DRIVER_CALL_FAILED'"):
    body=json.loads(row['body'])
    failures.append(dict(sequence=row['sequence'],**{k:v for k,v in body.items() if k in ('execution_id','request_id','path','error_type','error_code','error_chain')}))
print(json.dumps(dict(calls=calls,failures=failures,effect_stages=db.execute('SELECT count(*) FROM effect_intents').fetchone()[0])))
"""
def ledger():
    return json.loads(run("context",db_code))
def refreshes(snapshot):
    return [x for x in snapshot["calls"] if x["path"].endswith("TM/RefreshItem")]
def sim_state(set_clock=False):
    code="""
import json,urllib.request as u,sys
url='http://127.0.0.1:8085/api/v1/'
def get():return json.load(u.urlopen(url+'state',timeout=2))
s=get()
if sys.argv[1]=='start':
    assert s['transport']['profile']=='deterministic-local-test' and not s['running']
    body=json.dumps(dict(action='STEP',expected_epoch=s['epoch'],expected_revision=s['revision'])).encode()
    r=u.Request(url+'control',data=body,headers={'Content-Type':'application/json'})
    with u.urlopen(r,timeout=2) as f:assert f.status==200
    s=get()
print(json.dumps({k:s[k] for k in ['epoch','scenario_id','database_digest','running','revision']}|{'commands_executed':s['core']['commands_executed'],'tick':s['core']['tick'],'profile':s['transport']['profile']}))
"""
    return json.loads(run("simulator",code,"start" if set_clock else "read"))
def worker_slot(e):
    for role in ("worker","worker2"):
        if any(row.get("execution_id")==e and row["event"]=="native-ready" for row in native_events(role)):
            return role
def snapshot():
    r=observer.read("A","executions")["executions"]
    wanted={e["id"] for e in report["executions"].values()}
    return [{k:v for k,v in x.items() if k in {"id","procedure_id","state","owner","worker_slot","native_root_registered","native_root_result","hold_reason"}} for x in r if x["id"] in wanted]
def view(label):
    report["observations"][label]={"utc":utc(),"executions":snapshot()}
    save()
def resident_file(role):
    return "one" if role=="worker" else "two"
owner=SpellServerClient.from_config(case/"alice"/"connection.json")
observer=SpellServerClient.from_config(case/"observer"/"connection.json")
paused=False
try:
    original=statuses()
    assert all(s["Running"] and not s["Paused"] for s in original.values())
    assert len({s["Pid"] for s in original.values()})==len(original)
    report["initial_container_state"]=original
    config_code="import json;x=json.load(open('/credentials/config.json'))['native_driver'];print(json.dumps({k:x[k] for k in ('binding','url','tcp','commands','telemetry')}))"
    report["private_driver"]=json.loads(run("context",config_code))
    assert report["private_driver"]["commands"]==[] and report["private_driver"]["telemetry"]==["TM.POWER.BUS_VOLTAGE"]
    report["simulator_before"]=sim_state()
    assert report["simulator_before"]["commands_executed"]==0
    permissions=observer.read("A","health")
    assert permissions["subject"]=="observer" and set(permissions["permissions"])=={"context:read","execution:read"}
    report["observer"]={"subject":"observer","permissions":permissions["permissions"],"transport":"pinned mTLS HTTPS"}
    catalog=owner.read("A","procedures")["procedures"]
    assert {e["procedure_id"] for e in catalog}=={"sensors","witness"}
    connection=owner.authority("A","session.open",{},key=key())["connection_id"]
    for entry in sorted(catalog,key=lambda x:x["procedure_id"]):
        name=entry["procedure_id"]
        payload={k:entry[k] for k in ("procedure_id","source_revision","source_sha256","runtime_image","driver_binding")}
        expected=cfg["source_sha256" if name=="sensors" else "witness_source_sha256"]
        assert payload["source_sha256"]==expected and payload["source_revision"]==cfg["revision"] and payload["runtime_image"]==cfg["images"]["worker"]
        report["sources"][name]=payload
        reservation=owner.authority("A","execution.reserve",dict(payload,connection_id=connection),key=key())
        assert owner.remember_controller("A",reservation)
        eid=reservation["id"];report["executions"][name]={"id":eid}
        owner.launch("A",eid,key=key())
        role=bounded(lambda:worker_slot(eid),18,"Original worker did not report native-ready")
        report["executions"][name]["worker"]=role
        record("Original native root paused",procedure=name,execution=eid,worker=role)
    sensor=report["executions"]["sensors"];witness=report["executions"]["witness"]
    assert sensor["worker"]!=witness["worker"]
    report["baseline_fresh_sample"]=sim_state(True)
    for e in (witness,sensor):
        cmd=owner.command("A",e["id"],"CMD_RUN",key=key());assert cmd["admitted"]
    witness_dir=resident_file(witness["worker"]);sensor_dir=resident_file(sensor["worker"])
    first=bounded(lambda:marker_file(sensor_dir,"first-read"),18,"First ordinary telemetry read failed")
    assert first=="28.0"
    initial=ledger();report["ledger_before"]=initial
    assert [r["state"] for r in refreshes(initial)]==["COMPLETED"]
    assert initial["effect_stages"]==0
    tick=int(bounded(lambda:marker_file(witness_dir,"progress"),5,"Witness did not begin progress"))
    view("both_roots_before")
    record("Native GetTM returned 28.0 V with the independent worker progressing",value=float(first),witness_tick=tick)
    simid=ids["simulator"]
    assert statuses()["simulator"]["Pid"]==original["simulator"]["Pid"]
    docker("pause",simid);paused=True
    frozen=statuses()
    assert frozen["simulator"]["Paused"] and all(v["Running"] and not v["Paused"] for k,v in frozen.items() if k!="simulator")
    assert all(v["Pid"]==original[k]["Pid"] for k,v in frozen.items())
    report["interrupted_container_state"]=frozen
    t0=time.monotonic()
    marker("read-second")
    record("Signalled one native read while only the simulator cgroup was paused")
    seen_admitted=None
    def uncertain():
        global seen_admitted
        state=ledger();r=refreshes(state)
        if len(r)==2 and r[1]["state"]=="ADMITTED" and seen_admitted is None:
            seen_admitted={"utc":utc(),"since_marker_seconds":round(time.monotonic()-t0,3),"receipt":r[1]}
        if len(r)==2 and r[1]["state"]=="UNCERTAIN":return state
        return None
    view("simulator_paused")
    hurt=bounded(uncertain,9,"The authority did not mark the admitted read uncertain")
    t1=time.monotonic()
    report["admission_observation"]=seen_admitted
    report["uncertain_seconds_after_signal"]=round(t1-t0,3)
    report["ledger_interrupted"]=hurt
    assert seen_admitted and 2.5<=t1-t0<=5.5
    failed=refreshes(hurt)[1]
    assert failed["response_hash"] is None and failed["execution_id"]==sensor["id"]
    assert len(hurt["failures"])==1 and hurt["failures"][0]["request_id"]==failed["request_id"]
    advanced=int(marker_file(witness_dir,"progress"));assert advanced>tick
    view("uncertain_while_paused")
    record("The original read became uncertain while the other native root continued",request_id=failed["request_id"],witness_ticks=[tick,advanced])
    docker("unpause",simid);paused=False
    report["simulator_recovered"]=sim_state()
    assert report["simulator_recovered"]["commands_executed"]==0 and report["simulator_recovered"]["epoch"]==report["simulator_before"]["epoch"]
    t_restored=time.monotonic()
    states=[]
    while time.monotonic()-t_restored<6:
        observed=snapshot()
        states.append({"utc":utc(),"visible":observed})
        time.sleep(.5)
    report["observations"]["recovery_polls"]=states
    after=ledger();report["ledger_recovered"]=after
    assert after==hurt
    elapsed=time.monotonic()-t_restored
    late=int(marker_file(witness_dir,"progress"));assert late>advanced
    report["observation_after_restoration_s"]=round(elapsed,3)
    marker("finish-witness")
    def done():
        rows=snapshot()
        by_id={r["id"]:r for r in rows}
        return rows if set(by_id)=={sensor["id"],witness["id"]} and by_id[witness["id"]].get("native_root_result")=="FINISHED" and by_id[sensor["id"]].get("native_root_result") in {"FINISHED","ERROR","ABORTED"} else None
    terminal=bounded(done,18,"Native terminal outcomes were not visible")
    report["observations"]["terminal"]={"utc":utc(),"executions":terminal}
    for name,e in report["executions"].items():
        e["native_events"]=native_events(e["worker"])
        e["procedure_result"]=marker_file(resident_file(e["worker"]),"result")
    assert witness["procedure_result"]=="witness completed" and sensor["procedure_result"]=="DriverException"
    assert report["executions"]["witness"]["native_events"][-1]["event"]=="native-finished"
    assert sum(1 for x in after["calls"] if "/TC/" in x["path"])==0 and after["effect_stages"]==0
    assert ledger()==after
    report["observed_witness_ticks"]=[tick,advanced,late]
    report["simulator_after"]=sim_state()
    assert report["simulator_after"]["commands_executed"]==0
    record("The restored simulator and settled public views retained the original uncertain request without replay")
    report["passed"]=True
except BaseException as e:
    report["failure"]=type(e).__name__+": "+str(e)
    traceback.print_exc()
finally:
    if paused:
        docker("unpause",ids["simulator"])
    for role in ("worker","worker2"):
        p=subprocess.run(["docker","logs","--timestamps",ids[role]],text=True,capture_output=True)
        (case/(role+".log")).write_text(p.stdout+p.stderr,newline="\n")
    for client in (owner,observer):
        client.forget()
    save()
if not report["passed"]:raise SystemExit(1)

"""Compose the privately installed GENERIC adapter from the exact qualified inputs."""
from hashlib import sha256
import io,json,shutil,subprocess,tarfile
from pathlib import Path

base=Path(__file__).resolve().parent
work=base/'dss-image';work.mkdir(exist_ok=False)
root=base.parent.parent
repo=Path('C:/projects/openbexi_spell_plugin')
rev='47e0cb376dac1e49e1f6745318c0eb3e43b2ec4d'
core='sha256:b1b46dcda1f8db45889f6a145d2125362bbc04c41ded6e956ea99ca1ea61f968'
deps='sha256:489ff81aaa52ecbf09b4281499ed00f22fdd8b19e51e133a0202f2bbb6a40413'

def run(args,**kw):return subprocess.run(list(map(str,args)),check=True,**kw)
def out(args):return subprocess.check_output(list(map(str,args)),text=True).strip()
def sha(path):return sha256(path.read_bytes()).hexdigest()

wheel=next((root/'artifacts/spell'/rev).glob('openbexi_spell_dss-*.whl'))
assert sha(wheel)=='93e1b280ef192b4da0994b0fe66d8168dd702e582bcb5e0aa5e6d84c09361caa'
shutil.copy2(wheel,work/wheel.name)
raw=subprocess.check_output(['git','-C',str(repo),'archive',rev,'src/dss'])
with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
    for member in archive:
        if member.isfile():
            path=Path(member.name)
            assert path.parts[:2]==('src','dss') and '..' not in path.parts
            dest=work/path;dest.parent.mkdir(parents=True,exist_ok=True)
            with archive.extractfile(member) as fin:dest.write_bytes(fin.read())
tags={'obx-qualification-dss-dependencies:recovery-47e0cb37':deps,'obx-qualification-dss-core:recovery-47e0cb37':core}
for tag,pin in tags.items():
    run(['docker','tag',pin,tag]);assert out(['docker','image','inspect','--format','{{.Id}}',tag])==pin
packages=json.loads(out(['docker','run','--rm','--network','none','--read-only','--cap-drop','ALL','--entrypoint','python',deps,'-I','-c',"import importlib.metadata as m,json;print(json.dumps({p:m.version(p) for p in ('grpcio','protobuf')}))"]))
dock='''FROM obx-qualification-dss-dependencies:recovery-47e0cb37 AS dependencies
FROM obx-qualification-dss-core:recovery-47e0cb37
USER root
'''
for module in ('grpc','google',f"grpcio-{packages['grpcio']}.dist-info",f"protobuf-{packages['protobuf']}.dist-info"):
    p='/usr/local/lib/python3.13/site-packages/'+module
    dock+=f'COPY --from=dependencies {p} {p}\n'
dock+='''COPY *.whl /input/
RUN python -m pip install --no-index --no-deps --no-compile /input/*.whl
COPY src/dss/ /opt/qualification-simulator/dss/
USER 65532:65532
'''
(work/'Dockerfile').write_text(dock,newline='\n')
with (base/'build.log').open('w') as log:run(['docker','build','--network','none','--pull=false','--iidfile',base/'image.id',work],stdout=log,stderr=subprocess.STDOUT)
image=(base/'image.id').read_text().strip()
test="import sys,importlib.metadata as m,json;sys.path.insert(0,'/opt/qualification-simulator');from dss.local import create_servers;from openbexi_spell_dss.context_driver import ContextDriver;print(json.dumps({p:m.version(p) for p in ('openbexi-spell-dss','openbexi-spell-server','protobuf','grpcio')}))"
installed=json.loads(out(['docker','run','--rm','--network','none','--read-only','--cap-drop','ALL','--entrypoint','python',image,'-I','-c',test]))
receipt=dict(source=rev,core=core,dependency_image=deps,dss_wheel=wheel.name,dss_wheel_sha256=sha(wheel),runtime=image,installed=installed,recipe_sha256=sha(work/'Dockerfile'),simulator_sources={p.relative_to(work).as_posix():sha(p) for p in sorted((work/'src/dss').rglob('*')) if p.is_file()})
(base/'build.json').write_text(json.dumps(receipt,indent=2)+'\n',newline='\n');print(image)

from pathlib import Path
import time
from spell.lang.functions import GetTM
from spell.lib.exception import DriverException

workspace = Path("/audit")
value = GetTM("TM.POWER.BUS_VOLTAGE", Wait=False, HandleError=False)
assert value == 28.0
(workspace / "first-read").write_text(str(value))
deadline = time.monotonic() + 70
while not Path("/signals/read-second").exists():
    if time.monotonic() >= deadline:
        raise TimeoutError("Qualification operator did not signal the second read")
    time.sleep(0.05)
(workspace / "requesting").write_text("one second read")
try:
    GetTM("TM.POWER.BUS_VOLTAGE", Wait=False, HandleError=False)
except DriverException as failure:
    (workspace / "result").write_text(type(failure).__name__)
else:
    (workspace / "result").write_text("unexpected success")
    raise AssertionError("Interrupted simulator returned a value")

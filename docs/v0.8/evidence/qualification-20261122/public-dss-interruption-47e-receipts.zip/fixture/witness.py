from pathlib import Path
import time

workspace = Path("/audit")
deadline = time.monotonic() + 75
tick = 0
while not Path("/signals/finish-witness").exists():
    if time.monotonic() >= deadline:
        raise TimeoutError("Qualification witness watchdog expired")
    tick += 1
    pending = workspace / "progress.tmp"
    pending.write_text(str(tick))
    pending.replace(workspace / "progress")
    time.sleep(0.10)
(workspace / "result").write_text("witness completed")

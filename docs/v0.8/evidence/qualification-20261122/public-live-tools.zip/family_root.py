import os
import threading
import time
from spell.lang.functions import StartProc,Prompt
from spell.lang.constants import YES_NO
from spell.lang.modifiers import Type

def progress(name):
    sequence=0
    prompted=False
    while not os.path.exists("/control/handoff-finish"):
        if name=="root" and not prompted and os.path.exists("/control/handoff-open-prompt"):
            assert Prompt("Continue the original native family after transfer?",{Type:YES_NO}) is True
            prompted=True
        sequence+=1
        filename="/workspace/handoff-"+name
        with open(filename+".next","w") as stream:
            stream.write(str(sequence))
        os.replace(filename+".next",filename)
        time.sleep(0.05)

assert StartProc("handoff_child", Automatic=True, Visible=True, Blocking=False, HandleError=False) is True
threading.Thread(target=progress,args=("background",),daemon=True).start()
progress("root")
until=time.monotonic()+12
while not os.path.exists("/workspace/handoff-child-finished"):
    assert time.monotonic()<until
    time.sleep(0.05)
time.sleep(1)
with open("/workspace/approved-procedure-completed","w") as marker:
    marker.write("Native root, child and background survived the controller changes")

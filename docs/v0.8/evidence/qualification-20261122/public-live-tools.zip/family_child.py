import os
import time
sequence=0
while not os.path.exists("/control/handoff-finish"):
    sequence+=1
    with open("/workspace/handoff-child.next","w") as stream:
        stream.write(str(sequence))
    os.replace("/workspace/handoff-child.next","/workspace/handoff-child")
    time.sleep(0.05)
with open("/workspace/handoff-child-finished","w") as marker:
    marker.write("done")

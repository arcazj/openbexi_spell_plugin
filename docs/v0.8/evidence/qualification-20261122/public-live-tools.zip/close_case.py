import json
import re
import subprocess
import sys
from pathlib import Path

target = Path(sys.argv[1])
base = target.parent if target.is_absolute() else Path(__file__).parent
case = target.name
assert re.fullmatch(r"[a-z0-9]+", case)
f = base / case / "case.json"
spec = json.loads(f.read_text())
prefix = spec.get("prefix", "obx-public-launch-" + case)
if "prefix" not in spec:
    spec["volume"] = prefix + "-case"
    spec["networks"] = [prefix + "-" + role for role in ("edge", "service", "private")]
assert prefix == "obx-public-launch-" + case
extras = tuple(
    role
    for role in ("kernel", "operator")
    if subprocess.run(
        ["docker", "inspect", prefix + "-" + role],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    ).returncode
    == 0
)
roles = extras + ("worker", "gateway", "listener", "context")
names = [prefix + "-" + r for r in roles]


def docker(*args):
    return subprocess.check_output(["docker", *map(str, args)], text=True).strip()


before = [
    (
        r,
        docker(
            "inspect",
            "--format",
            "{{.Id}} {{.Image}} {{.State.Status}} {{.State.ExitCode}}",
            n,
        ),
    )
    for r, n in zip(roles, names)
]
for r, n in zip(roles, names):
    inspection = json.loads(docker("inspect", n))[0]
    assert inspection["Name"] == "/" + prefix + "-" + r and any(
        v.get("Name") == spec["volume"] for v in inspection["Mounts"]
    )
db = docker(
    "exec",
    names[-1],
    "python",
    "-c",
    "import sqlite3,json;d=sqlite3.connect('/state/context.sqlite3'); print(json.dumps(dict(executions=d.execute('select id,procedure_id,owner,lifecycle,control_state from executions').fetchall(),events=d.execute('select type,count(*) from events group by type').fetchall())))",
)
(f.parent / "fixture-cleanup.json").write_text(
    json.dumps(
        dict(
            containers=before, authority=json.loads(db), retained_volume=spec["volume"]
        ),
        indent=2,
    )
    + "\n"
)
docker("stop", "--time", "3", *names)
docker("rm", *names)
for network in spec["networks"]:
    assert network.startswith(prefix + "-")
    docker("network", "rm", network)
print("Retained volume", spec["volume"])

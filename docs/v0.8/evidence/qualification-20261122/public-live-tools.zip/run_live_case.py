"""Drive real browser controls with a separate, fixed-container operator witness."""

from pathlib import Path
import hashlib
import json
import os
import queue
import shutil
import subprocess
import sys
import threading
import time

base = Path(__file__).resolve().parent
case = base / sys.argv[1]
cfg = json.loads((case / "case.json").read_text())
directory = case / "live-browser"
kernel_file = case / "kernel.json"
log = {"passed": False, "rounds": []}
worker = cfg["prefix"] + "-worker"
host = cfg["operator"]
observer = cfg["prefix"] + "-kernel"


def save():
    kernel_file.write_text(json.dumps(log, indent=2) + "\n")


def command(*args, data=None, timeout=6):
    result = subprocess.run(
        list(map(str, args)),
        input=data,
        text=True,
        capture_output=True,
        timeout=timeout,
    )
    if result.returncode:
        raise RuntimeError(result.stderr[-1200:] or "Operator subprocess failed")
    return result.stdout.strip()


def docker(*args, **kw):
    return command("docker", *args, **kw)


def inspect(name):
    return json.loads(docker("inspect", name))[0]


def signal(k, v):
    full = directory / (k + ".json")
    tmp = full.with_suffix(".tmp")
    tmp.write_text(json.dumps(v))
    tmp.replace(full)


def await_in(k, seconds=40):
    until = time.monotonic() + seconds
    while not (directory / (k + ".json")).exists():
        if browser.poll() is not None:
            raise RuntimeError("Browser stopped before " + k)
        if time.monotonic() > until:
            raise TimeoutError(k)
        time.sleep(0.08)
    return json.loads((directory / (k + ".json")).read_text())


def event(kind, count=1, seconds=25):
    until = time.monotonic() + seconds
    while time.monotonic() < until:
        values = [
            json.loads(i)
            for i in docker("logs", worker).splitlines()
            if i.startswith("{")
        ]
        match = [i for i in values if i.get("event") == kind]
        if len(match) >= count:
            return match[count - 1]
        if inspect(worker)["State"]["Status"] == "exited":
            raise RuntimeError(
                "Worker exited waiting for "
                + kind
                + ": "
                + str(
                    [
                        r
                        for r in values[-3:]
                        if r.get("event")
                        in {"native-failed", "worker-failed", "native-terminal-failure"}
                    ]
                )[:800]
            )
        time.sleep(0.14)
    raise TimeoutError("Missing " + kind)


def rpc(action, **fields):
    data = dict(
        execution=execution, incarnation=incarnation, action=action, fields=fields
    )
    return json.loads(
        docker(
            "exec",
            "-i",
            host,
            "python",
            "-I",
            "/code/private_host_rpc.py",
            data=json.dumps(data),
        )
    )


def marker(action, value):
    return json.loads(
        docker(
            "exec",
            "-i",
            host,
            "python",
            "-I",
            "/code/private_host_rpc.py",
            data=json.dumps(dict(action=action, value=value)),
        )
    )


def get_kernel(seconds=8):
    try:
        line = inbox.get(timeout=seconds)
    except queue.Empty:
        raise TimeoutError("Scoped kernel observer did not respond") from None
    if not line:
        raise RuntimeError("Scoped kernel observer terminated")
    return json.loads(line)


def kernel(action, **kw):
    monitor.stdin.write(json.dumps(dict(action=action, **kw)) + "\n")
    monitor.stdin.flush()
    return get_kernel()


def frozen(state):
    info = inspect(worker)
    actual = kernel("freeze", members=state["members"])
    if (
        info["Id"] != bound
        or info["Image"] != cfg["worker_image"]
        or not (info["State"]["Paused"] and info["State"]["Running"])
    ):
        raise ValueError("Target Docker state differs")
    return dict(
        provider="docker-cgroup-freezer-pidfd/1",
        container_id=bound,
        image=info["Image"],
        paused=True,
        running=True,
        frozen=actual["frozen"],
        oom_killed=info["State"]["OOMKilled"],
        restart_count=info["RestartCount"],
        original_handles=actual["original_handles"],
        alive_handles=actual["alive_handles"],
        member_bindings=actual["member_bindings"],
        roster_hash=state["roster_hash"],
    ), actual


def advanced(a, b):
    return all(b[k] > v for k, v in a.items())


node = shutil.which("node")
if not node:
    raise RuntimeError("Node.js is required to drive pinned Chromium")
with (
    (case / "browser.log").open("w") as blog,
    (case / "observer.log").open("w") as klog,
):
    browser = subprocess.Popen(
        [node, str(base / "live_browser.cjs"), str(case)],
        env=dict(os.environ, NODE_EXTRA_CA_CERTS=str(case / "alice/ca.pem")),
        stdout=blog,
        stderr=subprocess.STDOUT,
    )
    monitor = None
    try:
        reserved = await_in("reserved", 35)
        execution, incarnation = reserved["execution"], reserved["incarnation"]
        initial = inspect(worker)
        bound = initial["Id"]
        assert (
            initial["State"]["Status"] == "created"
            and initial["Image"] == cfg["worker_image"]
        )
        binding = rpc("bind", container_id=bound, image=cfg["worker_image"])
        assert binding["container_id"] == bound
        docker("start", bound, timeout=40)
        signal("host-bound", binding)
        epoch = await_in("admitted")["id"]
        marker("epoch", epoch)
        event("native-child-running", seconds=40)
        log.update(
            execution=execution,
            container_id=bound,
            image=cfg["worker_image"],
            service_image=cfg["server_image"],
            source=cfg["source_sha256"],
        )
        docker(
            "create",
            "-i",
            "--name",
            observer,
            "--pid",
            "container:" + bound,
            "--cgroupns",
            "host",
            "--network",
            "none",
            "--read-only",
            "--cap-drop",
            "ALL",
            "--security-opt",
            "no-new-privileges",
            "--user",
            "10003:10003",
            "--mount",
            f"type=volume,src={cfg['volume']},dst=/code,volume-subpath=operator-code,readonly",
            "--entrypoint",
            "python",
            cfg["worker_image"],
            "-I",
            "/code/kernel_observer.py",
            bound,
        )
        monitor = subprocess.Popen(
            ["docker", "start", "-a", "-i", observer],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=klog,
            text=True,
            bufsize=1,
        )
        inbox = queue.Queue()

        def receive():
            for line in monitor.stdout:
                inbox.put(line)
            inbox.put("")

        threading.Thread(target=receive, daemon=True).start()
        log["original_kernel_roster"] = get_kernel()
        first = kernel("sample")
        time.sleep(0.6)
        later = kernel("sample")
        assert advanced(first["counters"], later["counters"])
        marker("prompt", None)
        signal("family-ready", {})
        save()
        for i in range(1, 4):
            request = await_in("request-" + str(i))
            marker("drain", epoch)
            drained = event("native-handoff-agent-drained", i, seconds=12)
            assert (
                drained["runtime_epoch"] == epoch
                and drained["active_calls"] == 0
                and drained["quiescence_proven"] is False
            )
            state = rpc("status")
            assert (
                state["barrier_id"] == request["barrier"]
                and state["state"] == "REQUESTED"
            )
            docker("pause", bound)
            proof, point = frozen(state)
            time.sleep(3)
            stable = kernel("sample")
            assert stable["frozen"] and point["counters"] == stable["counters"]
            completed = rpc("complete", barrier_id=request["barrier"], evidence=proof)
            assert (
                completed["quiescence_proven"]
                and completed["state"] == "TRANSFERRED_PAUSED"
            )
            signal("frozen-" + str(i), {"operation": completed["operation"]})
            rid = await_in("resume-" + str(i))["id"]
            resume_state = rpc("status")
            proof2, again = frozen(resume_state)
            assert proof2 == proof and again["counters"] == stable["counters"]
            authorized = rpc(
                "resume", barrier_id=request["barrier"], resume_id=rid, evidence=proof2
            )
            next_epoch = authorized["runtime_epoch"]
            if next_epoch != rid or next_epoch == epoch:
                raise RuntimeError("Invalid host-authorized rotation")
            marker("epoch", next_epoch)
            docker("unpause", bound)
            epoch = next_epoch
            activated = event("native-handoff-activated", i, seconds=12)
            assert activated["rotation"] == i and activated["runtime_identity_rotated"]
            resumed = kernel("sample")
            until = time.monotonic() + 6
            moving = (
                ("child", "background") if i == 1 else ("root", "child", "background")
            )

            def continued():
                return all(
                    resumed["counters"][k] > again["counters"][k] for k in moving
                )

            while not continued() and time.monotonic() < until:
                time.sleep(0.1)
                resumed = kernel("sample")
            assert continued() and not resumed["frozen"]
            log["rounds"].append(
                dict(
                    rotation=i,
                    barrier=request["barrier"],
                    controller_operation=completed["operation"],
                    proof=proof,
                    stopped=point["counters"],
                    still_stopped=stable["counters"],
                    continued=resumed["counters"],
                    true_handles=log["original_kernel_roster"]["original_pids"],
                )
            )
            save()
            signal("activated-" + str(i), {})
            if i == 1:
                answered = await_in("answered-1")
                until = time.monotonic() + 7
                resumed = kernel("sample")
                while (
                    not advanced(again["counters"], resumed["counters"])
                    and time.monotonic() < until
                ):
                    time.sleep(0.08)
                    resumed = kernel("sample")
                assert advanced(again["counters"], resumed["counters"])
                log["transferred_prompt"] = dict(
                    answered=answered, resumed_root_child_background=resumed["counters"]
                )
                save()
                signal("answer-observed", {})
        await_in("finish-request")
        marker("finish", None)
        term = event("native-finished", seconds=30)
        assert term["native_status"] == "FINISHED" and term["hold_retained"]
        rc = browser.wait(30)
        assert rc == 0 and json.loads((directory / "result.json").read_text())["passed"]
        journal = """import json,sqlite3
db=sqlite3.connect('file:/state/context.sqlite3?mode=ro',uri=True)
db.row_factory=sqlite3.Row
queries={'members':'SELECT target_id,instance_id,pid,parent_pid,executable_sha256 FROM native_members ORDER BY target_id',
'prompts':'SELECT prompt_id,state,outcome,definition_hash FROM native_prompts',
'replies':'SELECT owner,epoch,connection_generation,action,state,diagnostic FROM native_prompt_replies',
'root_result':'SELECT execution_id,native_status FROM assigned_native_results',
'control':'SELECT owner,epoch,connection_generation,control_state FROM executions',
'worker_spent':'SELECT spent FROM workers'}
print(json.dumps({k:[dict(row) for row in db.execute(q)] for k,q in queries.items()}))
"""
        durable = json.loads(
            docker("exec", cfg["prefix"] + "-context", "python", "-I", "-c", journal)
        )
        assert len(durable["members"]) == 2 and {
            m["instance_id"] for m in durable["members"]
        } == {"main#1", "handoff_child#0"}
        assert len({m["executable_sha256"] for m in durable["members"]}) == 1
        assert durable["replies"] == [
            {
                "owner": "bob",
                "epoch": 2,
                "connection_generation": 2,
                "action": "ANSWER",
                "state": "CONSUMED_UNPROVEN",
                "diagnostic": "IPC_SEND_ACKNOWLEDGED",
            }
        ]
        assert (
            durable["prompts"][0]["state"] == "CLOSED"
            and durable["prompts"][0]["outcome"] == "ANSWER_SELECTED"
        )
        assert (
            len(durable["prompts"]) == 1
            and durable["prompts"][0]["prompt_id"]
            == log["transferred_prompt"]["answered"]["id"]
        )
        assert durable["root_result"] == [
            {"execution_id": execution, "native_status": "FINISHED"}
        ]
        assert (
            durable["control"][0]["owner"] == "alice"
            and durable["control"][0]["epoch"] == 3
        )
        assert durable["worker_spent"] == [{"spent": 1}]
        raw = docker("logs", "--timestamps", bound, timeout=20)
        (case / "worker.log").write_text(raw)
        archive = "from pathlib import Path;import hashlib,json;print(json.dumps([dict(name=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(Path('/audit').rglob('*')) if p.is_file()]))"
        asrun = json.loads(
            docker(
                "run",
                "--rm",
                "--read-only",
                "--network",
                "none",
                "--cap-drop",
                "ALL",
                "--security-opt",
                "no-new-privileges",
                "--user",
                "10003:10003",
                "--mount",
                f"type=volume,src={cfg['volume']},dst=/audit,volume-subpath=audit,readonly",
                "--entrypoint",
                "python",
                cfg["worker_image"],
                "-I",
                "-c",
                archive,
                timeout=20,
            )
        )
        assert (
            len([f for f in asrun if f["name"].endswith(".ASRUN") and f["bytes"] > 0])
            == 2
        )
        log.update(
            durable=durable,
            asrun=asrun,
            worker_log_sha256=hashlib.sha256(
                (case / "worker.log").read_bytes()
            ).hexdigest(),
        )
        log.update(passed=True, finished=term)
    except Exception as ex:
        log["error"] = str(ex)
        log["worker_at_failure"] = {
            k: v
            for k, v in inspect(worker)["State"].items()
            if k in {"Running", "Paused", "Status", "ExitCode"}
        }
        raise
    finally:
        save()
        if browser.poll() is None:
            try:
                browser.wait(3)
            except subprocess.TimeoutExpired:
                browser.terminate()
        if monitor and monitor.poll() is None:
            try:
                monitor.stdin.write('{"action":"close"}\n')
                monitor.stdin.flush()
                monitor.wait(3)
            except (OSError, subprocess.TimeoutExpired):
                monitor.terminate()
        print(
            json.dumps(
                dict(
                    ok=log["passed"], rounds=len(log["rounds"]), error=log.get("error")
                )
            )
        )

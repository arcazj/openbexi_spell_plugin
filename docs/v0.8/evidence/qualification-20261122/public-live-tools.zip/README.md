# Browser qualification for an original native family

This fixture holds the same native root, native child and background thread through two explicit controller transfers and a same-owner reconnect. The root opens an untimed YES/NO question under Alice. Bob receives the existing question, answers it once, and Alice later regains control. Three named browser users and twenty additional observers authenticate using separate certificates.

## Run the case

Use a disposable Docker host running Linux containers with cgroup v2, PID namespace sharing for the named worker, and Linux pidfd support. Install Python 3.13, Node.js, Playwright Core 1.65.0 and its Chrome for Testing 158.0.8127.18. The Windows executable digest is checked in `live_browser.cjs`. `PLAYWRIGHT_MODULE` can point to an existing Playwright Core installation. The container images must already be present locally. Use the full local OCI image IDs in the accompanying receipt for the worker, Gateway and core, and the separately pinned issuer image for the private one-day certificates and immutable Git fixture.

```text
python start_case.py live01 --output-root CASE_DIRECTORY --server GATEWAY_IMAGE_ID --core CORE_IMAGE_ID --runtime WORKER_IMAGE_ID --provisioner ISSUER_IMAGE_ID --lab-net 58
python run_live_case.py ABSOLUTE_CASE_DIRECTORY/live01
python capture_policy.py ABSOLUTE_CASE_DIRECTORY/live01
python close_case.py ABSOLUTE_CASE_DIRECTORY/live01
```

Choose a fresh case name and a free `198.19.<lab-net>.0/24` subnet. The Gateway publishes only to loopback. Keep the private case directory and named Docker volume in the test operator's custody. The browser, worker and serving roles receive separate credentials. The separate host-side operator uses the Docker CLI for the admitted container only. The observer holds pidfds in the worker's PID namespace, reads its cgroup and has zero Linux capabilities and no network. Services and the witness receive no Docker socket.

`live-browser/result.json` contains the authenticated browser observations, actions and WebSocket counts. `kernel.json` contains frozen and advancing counters, original pidfds, native binary identity, stored prompt outcome, root result and both ASRUN hashes. `worker.log` records the timestamped operation. `capture_policy.py` verifies the original container roles, mount permissions, capabilities, namespaces, memory settings and loopback binding before teardown. `close_case.py` checks the generated container names and volume mounts, retires this case and retains its audit volume. The fixture exercises an audit-only procedure and has no external driver effects.

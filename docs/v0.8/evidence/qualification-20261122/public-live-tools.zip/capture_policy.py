import hashlib
import json
from pathlib import Path
import subprocess
import sys

case = Path(__file__).resolve().parent / sys.argv[1]
cfg = json.loads((case / "case.json").read_text())
roles = ("gateway", "listener", "context", "worker", "operator", "kernel")
policy = {}
for role in roles:
    raw = subprocess.check_output(
        ["docker", "inspect", cfg["prefix"] + "-" + role], text=True
    )
    actual = json.loads(raw)[0]
    host = actual["HostConfig"]
    mounts = {m["Destination"]: m["RW"] for m in actual["Mounts"]}
    assert (
        host["ReadonlyRootfs"]
        and "ALL" in host["CapDrop"]
        and not host["CapAdd"]
        and not host["Privileged"]
    )
    assert any(s.startswith("no-new-privileges") for s in host["SecurityOpt"])
    assert not any("docker.sock" in path for path in mounts)
    assert actual["Config"]["User"] == (
        "65532:65532" if role in {"gateway", "listener", "context"} else "10003:10003"
    )
    policy[role] = dict(
        id=actual["Id"],
        image=actual["Image"],
        uid_gid=actual["Config"]["User"],
        read_only_root=host["ReadonlyRootfs"],
        dropped_capabilities=host["CapDrop"],
        added_capabilities=host["CapAdd"] or [],
        privileged=host["Privileged"],
        security=host["SecurityOpt"],
        network_mode=host["NetworkMode"],
        networks=sorted(actual["NetworkSettings"]["Networks"]),
        pid_mode=host["PidMode"],
        cgroup_namespace=host["CgroupnsMode"],
        mount_read_write=mounts,
        pids_limit=host.get("PidsLimit"),
        memory_bytes=host["Memory"],
        memory_swap_bytes=host["MemorySwap"],
        published_ports=host.get("PortBindings") or {},
    )
assert (
    policy["gateway"]["image"] == cfg["server_image"]
    and policy["gateway"]["published_ports"]["9443/tcp"][0]["HostIp"] == "127.0.0.1"
)
assert policy["listener"]["image"] == policy["context"]["image"] == cfg["core_image"]
assert (
    policy["worker"]["image"] == cfg["worker_image"]
    and policy["worker"]["memory_bytes"]
    == policy["worker"]["memory_swap_bytes"]
    == 1536 * 1024**2
)
assert (
    policy["worker"]["mount_read_write"]["/source"] is False
    and policy["worker"]["mount_read_write"]["/control"] is False
)
assert (
    policy["operator"]["mount_read_write"]["/control"]
    and policy["kernel"]["pid_mode"] == "container:" + policy["worker"]["id"]
)
assert (
    policy["kernel"]["network_mode"] == "none"
    and policy["kernel"]["cgroup_namespace"] == "host"
)
assert not any(v["pid_mode"] == "host" for v in policy.values())
path = case / "host-policy.json"
path.write_text(json.dumps(policy, indent=2) + "\n", newline="\n")
print(path.name, hashlib.sha256(path.read_bytes()).hexdigest())

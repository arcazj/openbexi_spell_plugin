"""Fixture-local operator TLS client. Only fixed private host routes and epoch markers."""

from pathlib import Path
import json
import os
import sys
import uuid
from openbexi_spell_server.transport import Route, tls_context


def identity(value):
    if str(uuid.UUID(value)) != value:
        raise ValueError("Expected canonical UUID")
    return value


def main():
    req = json.load(sys.stdin)
    action = req["action"]
    if action in {"epoch", "drain", "finish", "prompt"}:
        filename = {
            "epoch": "handoff-epoch",
            "drain": "handoff-prepare",
            "finish": "handoff-finish",
            "prompt": "handoff-open-prompt",
        }[action]
        value = identity(req["value"]) if action in {"epoch", "drain"} else action
        path = Path("/control") / filename
        intermediate = path.with_suffix(".next")
        intermediate.write_text(value)
        os.replace(intermediate, path)
        print(json.dumps({"written": filename}))
        return
    endpoints = {
        "bind": ("terminal", "openbexi.host-terminal/1"),
        "status": ("handoff", "openbexi.host-handoff/1"),
        "complete": ("handoff", "openbexi.host-handoff/1"),
        "resume": ("handoff", "openbexi.host-handoff/1"),
    }
    kind, schema = endpoints[action]
    config = json.loads(Path("/credentials/config.json").read_text())
    route = Route(
        "https://context:9443",
        config["context_fingerprint"],
        tls_context(
            "/credentials/ca.pem", "/credentials/tls.pem", "/credentials/tls.key"
        ),
    )
    payload = dict(
        req["fields"],
        schema=schema,
        context_id=config["context_id"],
        execution_id=identity(req["execution"]),
        authority_incarnation=identity(req["incarnation"]),
    )
    print(
        json.dumps(route.call(payload, path=f"/v1/host/{kind}/{action}", schema=schema))
    )


main()

const fs = require("node:fs"),
  path = require("node:path"),
  crypto = require("node:crypto");
const library = process.env.PLAYWRIGHT_MODULE || "playwright-core";
const { chromium } = require(library);
const root = path.resolve(process.argv[2]),
  dir = path.join(root, "live-browser");
fs.mkdirSync(dir);
const origin = JSON.parse(
  fs.readFileSync(path.join(root, "alice/connection.json")),
).url;
const report = { passed: false, observations: [], wss: {}, actions: [] };
const file = (s) => path.join(dir, s + ".json");
const write = (k, v) => {
  fs.writeFileSync(file(k) + ".next", JSON.stringify(v, null, 2));
  fs.renameSync(file(k) + ".next", file(k));
};
const mark = (name, details = {}) => {
  report.observations.push({
    name,
    time: new Date().toISOString(),
    ...details,
  });
  write("result", report);
  console.log(name);
};
const ms = (n) => new Promise((r) => setTimeout(r, n));
async function until(cb, why, seconds = 25) {
  const d = Date.now() + seconds * 1000;
  while (Date.now() < d) {
    if (await cb()) return;
    await ms(100);
  }
  throw Error("Timed out: " + why);
}
async function signal(key) {
  await until(() => fs.existsSync(file(key)), key, 64);
  return JSON.parse(fs.readFileSync(file(key)));
}
const select = async (p) => {
  await until(
    () => p.locator("#executions button").first().isVisible(),
    "execution selected",
  );
  await p.locator("#executions button").first().click();
};
const click = async (p, id) => {
  await p.locator("#" + id).click({ timeout: 12000 });
};
const get = async (p, name) =>
  p.evaluate(
    async (n) =>
      (await (await fetch("/workspace/v1/contexts/A/" + n)).json()).result,
    name,
  );
const row = async (p) => (await get(p, "executions")).executions[0];
const response = (p, method, endpoint) =>
  p.waitForResponse(
    (r) =>
      r.request().method() === "POST" &&
      r.url().endsWith("/" + endpoint) &&
      (!method || r.request().postDataJSON()?.method === method),
    { timeout: 20000 },
  );
async function act(p, button, method, endpoint = "authority") {
  report.actions.push({ button, at: new Date().toISOString() });
  write("result", report);
  const v = response(p, method, endpoint);
  await click(p, button);
  let raw;
  try {
    raw = await v;
  } catch (e) {
    throw Error(button + " response missing: " + e.message);
  }
  if (raw.status() !== 200) throw Error(button + " returned " + raw.status());
  return (await raw.json()).result;
}
async function stale(page, proof) {
  return await page.evaluate(
    async (p) =>
      (
        await fetch("/workspace/v1/contexts/A/commands", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Idempotency-Key": crypto.randomUUID(),
          },
          body: JSON.stringify({
            ...p,
            target_admission_id: null,
            command: "CMD_RUN",
          }),
        })
      ).status,
    proof,
  );
}
function original(r) {
  return {
    execution_id: r.id,
    connection_id: r.connection_id,
    expected_epoch: r.epoch,
    connection_generation: r.connection_generation,
    capability: r.capability,
  };
}
async function open(browser, role) {
  const d = path.join(root, role),
    c = await browser.newContext({
      clientCertificates: [
        {
          origin,
          certPath: path.join(d, "tls.pem"),
          keyPath: path.join(d, "tls.key"),
        },
      ],
    });
  const p = await c.newPage();
  report.wss[role] = { connections: 0, pages: 0, last_cursor: 0 };
  p.on("websocket", (s) => {
    const v = report.wss[role];
    v.connections++;
    s.on("framereceived", (f) => {
      const l = JSON.parse(f.payload);
      v.pages++;
      v.last_cursor = l.next_sequence;
    });
  });
  await p.goto(origin + "/workspace/");
  await until(
    async () =>
      (await p.locator("#identity").textContent()) === role &&
      report.wss[role].pages > 0,
    role + " authenticated",
  );
  return p;
}
(async () => {
  const browser = await chromium.launch({
    executablePath: chromium.executablePath(),
    headless: true,
  });
  try {
    report.browser = browser.version();
    report.playwright = require(library + "/package.json").version;
    report.chromium_sha256 = crypto
      .createHash("sha256")
      .update(fs.readFileSync(chromium.executablePath()))
      .digest("hex");
    if (report.browser !== "158.0.8127.18" || report.playwright !== "1.65.0")
      throw Error("Pinned browser or driver differs");
    if (
      process.platform === "win32" &&
      report.chromium_sha256 !==
        "dafaf388c1194eb610fc5706ba986eb38e5ebedb1fae44f39569e20940a3bae2"
    )
      throw Error("Windows qualification Chromium executable differs");
    const [alice, bob, observer] = await Promise.all(
      ["alice", "bob", "observer"].map((r) => open(browser, r)),
    );
    const observers = [];
    for (let i = 1; i <= 20; i += 3) {
      observers.push(
        ...(await Promise.all(
          Array.from({ length: Math.min(3, 21 - i) }, (_, j) =>
            open(browser, "watch-" + String(i + j).padStart(2, "0")),
          ),
        )),
      );
    }
    const roles = Object.keys(report.wss);
    if (
      new Set(
        roles.map(
          (role) =>
            new crypto.X509Certificate(
              fs.readFileSync(path.join(root, role, "tls.pem")),
            ).fingerprint256,
        ),
      ).size !== 23
    )
      throw Error("Expected 23 independently authenticated roles");
    const readOnlyMutation = (p) =>
      p.evaluate(
        async () =>
          (
            await fetch("/workspace/v1/contexts/A/authority", {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                "Idempotency-Key": crypto.randomUUID(),
              },
              body: JSON.stringify({ method: "session.open", payload: {} }),
            })
          ).status,
      );
    for (const p of observers)
      if ((await readOnlyMutation(p)) !== 403)
        throw Error("Observer mutation admitted");
    mark(
      "Twenty separately authenticated observers established actual WSS and received 403 for a controller mutation",
    );
    await alice.locator("#procedures").selectOption("approved-main");
    const res = await act(alice, "reserve", "execution.reserve");
    const health = await get(alice, "health");
    report.execution = res.id;
    write("reserved", { execution: res.id, incarnation: health.incarnation });
    await signal("host-bound");
    await select(alice);
    const launch = await act(alice, "start", "execution.launch");
    write("admitted", { id: launch.request_id });
    await until(
      () => alice.locator("#run").isEnabled(),
      "registered original root",
    );
    await act(alice, "run", null, "commands");
    await select(bob);
    await select(observer);
    await signal("family-ready");
    mark("Original root, native child and background are running");
    await until(
      () => alice.locator("#viewprompt").isVisible(),
      "opening owner sees pending original native prompt",
    );
    const originalPrompt = (
      await act(alice, "viewprompt", "execution.prompt.view")
    ).prompt;
    if (
      originalPrompt.text !==
        "Continue the original native family after transfer?" ||
      originalPrompt.choices.join("/") !== "Y/N"
    )
      throw Error("Wrong original prompt");
    await click(alice, "dismissprompt");
    if (
      (await bob.locator("#viewprompt").isVisible()) ||
      (await observer.locator("#viewprompt").isVisible())
    )
      throw Error("Prompt details visible to nonowner");
    let old = original(res),
      owner = alice,
      other = bob;
    for (let round = 1; round <= 3; round++) {
      let decision;
      if (round <= 2) {
        await act(other, "claim", "execution.claim");
        await until(
          () => owner.locator("#accept").isEnabled(),
          "controller can decide",
        );
        decision = await act(owner, "accept", "execution.decide");
      } else {
        await click(owner, "connection");
        await until(
          async () =>
            (await owner.locator("#connection").textContent()) === "Connect",
          "explicit disconnect",
        );
        await until(
          async () =>
            (await row(observer)).control_state === "CONTROLLER_DISCONNECTED",
          "observer saw detached controller",
        );
        await click(owner, "connection");
        await select(owner);
        if (await owner.locator("#run").isEnabled())
          throw Error("Reconnect resumed automatically");
        mark("Disconnected owner reconnected with read-only observation");
        decision = await act(owner, "rebind", "execution.rebind");
        if (!decision.rebind_pending) throw Error("Reconnect skipped freezer");
      }
      if (!decision.barrier_id)
        throw Error("Decision missing original barrier");
      write("request-" + round, { barrier: decision.barrier_id });
      await signal("frozen-" + round);
      const effective = await row(observer);
      const expected = round === 1 ? "bob" : "alice";
      if (
        effective.owner !== expected ||
        effective.control_state !== "HANDOFF_PAUSED" ||
        !effective.pause_barrier.quiescence_proven
      )
        throw Error("No proven paused owner");
      if ((await stale(owner, old)) !== 403)
        throw Error("Previous-generation RUN accepted");
      if (round <= 2) {
        const t = owner;
        owner = other;
        other = t;
      }
      await select(owner);
      await until(
        () => owner.locator("#rebind").isEnabled(),
        "new controller explicit rebind",
      );
      const rebound = await act(owner, "rebind", "execution.rebind");
      old = original(rebound);
      if (!old.capability) throw Error("No freshly delivered controller proof");
      await until(
        () => owner.locator("#run").isEnabled(),
        "explicit native family continuation",
      );
      const resume = await act(owner, "run", null, "commands");
      if (!resume.family_resume || resume.state !== "RESUME_REQUESTED")
        throw Error("Explicit resume not held for external host evidence");
      write("resume-" + round, { id: resume.command_id });
      await signal("activated-" + round);
      const active = await row(observer);
      if (
        active.owner !== expected ||
        active.control_state !== "OWNED" ||
        active.pause_barrier?.runtime_identity_rotated !== true
      )
        throw Error("Runtime identity not acknowledged");
      mark(
        "Independently proven live " +
          (round === 3
            ? "same-owner reconnect"
            : round === 1
              ? "A to B transfer"
              : "B to A transfer"),
        {
          owner: expected,
          epoch: active.epoch,
          generation: active.connection_generation,
          denied_stale_command_status: 403,
          barrier: decision.barrier_id,
        },
      );
      await owner.screenshot({
        path: path.join(dir, "round-" + round + ".png"),
      });
      if (round === 1) {
        await until(
          () => owner.locator("#viewprompt").isVisible(),
          "B can view the transferred prompt",
        );
        const same = (await act(owner, "viewprompt", "execution.prompt.view"))
          .prompt;
        for (const field of [
          "prompt_id",
          "definition_sha256",
          "target_admission_id",
          "text",
        ])
          if (same[field] !== originalPrompt[field])
            throw Error("Prompt changed on transfer");
        if (same.choices.join("/") !== "Y/N")
          throw Error("Native options changed on transfer");
        await owner.locator("#promptchoices").selectOption({ index: 0 });
        await act(owner, "answer", "execution.prompt.reply");
        write("answered-1", {
          id: same.prompt_id,
          digest: same.definition_sha256,
        });
        await signal("answer-observed");
        mark(
          "B answered A's original native question through the visible widget",
          {
            prompt_id: same.prompt_id,
            definition_sha256: same.definition_sha256,
          },
        );
      }
    }
    write("finish-request", {});
    await until(
      async () => (await row(observer)).native_root_result === "FINISHED",
      "native result",
      60,
    );
    await until(
      async () =>
        (
          await Promise.all(
            observers.map((p) =>
              p
                .locator("#executions tr")
                .first()
                .locator("td")
                .nth(4)
                .textContent(),
            ),
          )
        ).every((s) => s === "FINISHED"),
      "twenty observers saw FINISHED",
    );
    mark(
      "Twenty observers saw original native procedure finish after two transfers and a reconnect",
    );
    report.passed = true;
  } catch (e) {
    report.error = String(e);
    console.error(report.error);
    process.exitCode = 1;
  } finally {
    write("result", report);
    await browser.close();
  }
})().catch((e) => {
  report.error = String(e);
  write("result", report);
  process.exitCode = 1;
});

"""Keep pidfds open only in one worker PID namespace and inspect its read-only cgroup."""

import hashlib
import json
import os
from pathlib import Path
import select
import sys

container = sys.argv[1]
if len(container) != 64 or any(c not in "0123456789abcdef" for c in container):
    raise ValueError("Invalid container identity")
init = Path("/proc/1")
group_line = (init / "cgroup").read_text().splitlines()
if len(group_line) != 1 or not group_line[0].startswith("0::/"):
    raise ValueError("Unified target cgroup required")
relative = group_line[0][3:].lstrip("/")
if Path(relative).name not in {container, "docker-" + container + ".scope"}:
    raise ValueError("Unexpected worker cgroup")
group = Path("/sys/fs/cgroup") / relative


def pids():
    return sorted({int(i) for i in (group / "cgroup.procs").read_text().split()})


original = pids()
handles = {i: os.pidfd_open(i) for i in original}
print(json.dumps(dict(ready=True, original_pids=original)), flush=True)
for line in sys.stdin:
    value = json.loads(line)
    if value.get("action") == "close":
        break
    if value.get("action") not in {"sample", "freeze"}:
        raise ValueError("Unknown operation")
    now = pids()
    if sorted(handles) != now or any(
        select.select([fd], [], [], 0)[0] for fd in handles.values()
    ):
        raise RuntimeError("Original native family roster changed")
    stock = init / "root/workspace"
    counts = {
        k: int((stock / ("handoff-" + k)).read_text())
        for k in ("root", "child", "background")
    }
    events = dict(
        row.split() for row in (group / "cgroup.events").read_text().splitlines()
    )
    response = dict(
        pids=now,
        original_handles=len(handles),
        alive_handles=len(handles),
        frozen=events.get("frozen") == "1",
        counters=counts,
    )
    if value["action"] == "freeze":
        if not response["frozen"]:
            raise RuntimeError("Kernel has not acknowledged complete cgroup freeze")
        actual = []
        for m in value["members"]:
            if m["pid"] not in handles:
                raise ValueError("Admitted member absent from original PID roster")
            proc = Path("/proc") / str(m["pid"])
            stat = (proc / "stat").read_text()
            ticks = int(stat[stat.rfind(")") + 2 :].split()[19])
            if (
                ticks != m["start_ticks"]
                or hashlib.sha256((proc / "exe").read_bytes()).hexdigest()
                != m["executable_sha256"]
            ):
                raise ValueError("Original Executor executable or birth ticks differ")
            actual.append(m["binding_hash"])
        if len(actual) != len(set(actual)) or len(actual) < 2:
            raise ValueError("Distinct native parent and child required")
        response["member_bindings"] = sorted(actual)
    print(json.dumps(response), flush=True)

import json,os,sys,traceback
from pathlib import Path
os.chdir('/workspace/native-language-results')
sys.path.insert(0,'/source')
from domain_selected import SOURCES
rows={}
for key,source in SOURCES.items():
    Path('current.json').write_text(json.dumps(dict(check=key)))
    try:
        exec(compile(source,'unchanged historical '+key,'exec'),{})
        verdict={'passed':True}
    except Exception as error:
        verdict={'passed':False,'error':type(error).__name__+': '+str(error),'traceback':traceback.format_exc()}
    observed=Path('observed.json')
    if observed.exists():observed.rename('observed-'+key+'.json')
    rows[key]=dict(verdict,expected_prompts=[],source=source)
    Path('checks.json').write_text(json.dumps(rows,indent=2))
import v08_native_language_batch as observer
observer.SPECS=(*observer.SPECS,{'name':'limitprobe','files':['domain_selected.py']})
observer.write_runtime_identity('limitprobe')

from pathlib import Path
import sys,shutil,json,hashlib,subprocess
w=Path(__file__).resolve().parents[1];r=Path('C:/projects/openbexi_spell_plugin');f=w/'limitprobe';o=f/'original-inputs';o.mkdir(exist_ok=True);sys.path.insert(0,str(r/'conformance'));checks={}
for label,case,source,ref in [('named-limit','named:positive','limit_features_cases','v05_limit_complete'),('ranging','dual:positive','ranging_complete_cases','ranging_complete_review'),('memory','json-golden','memory_complete_cases','memory_complete_review'),('scheduled-command','Time:positive','command_scheduling_cases','command_display_composed')]:
 j=json.loads((r/'conformance/evidence'/(ref+'.json')).read_bytes());row=j['checks'][case];path='conformance/'+source+'.py';key=j.get('inputs',j.get('source_inputs',{}))[path];data=(r/path).read_bytes();
 if hashlib.sha256(data).hexdigest()!=key:
  archived=w/'historical-top-level'/key;data=archived.read_bytes() if archived.is_file() else subprocess.check_output(['git','show',j['source_revision']+':'+path],cwd=r)
 assert hashlib.sha256(data).hexdigest()==key and row['passed'];(o/(source+'.py')).write_bytes(data);ns={};exec(compile(data,str(o/(source+'.py')),'exec'),ns);body=ns['CASES'][case]['source'];assert row.get('source',body)==body and row.get('source_sha256',hashlib.sha256(body.encode()).hexdigest())==hashlib.sha256(body.encode()).hexdigest(),label;checks[label]=dict(source=body,expected_prompts=[],contracts=[],archived_check=case,archived_report=ref+'.json',source_path=path,source_sha256=key)
(f/'original-selection.json').write_bytes((json.dumps({'checks':checks},indent=2)+'\n').encode());(f/'input/domain_selected.py').write_bytes(('SOURCES = '+repr({k:v['source'] for k,v in checks.items()})+'\n').encode())

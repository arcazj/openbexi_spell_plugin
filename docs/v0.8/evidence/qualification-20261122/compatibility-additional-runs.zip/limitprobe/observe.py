import hashlib,json,time,urllib.error,urllib.parse,urllib.request
from pathlib import Path
work=Path('/work'); source=work/'fixture-request.json'; host='http://127.0.0.1:8085/api/v1/'
feeding=True;clock=time.monotonic(); last=None; current=None; changed=None; state=None
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
def request(route,payload=None):
    query=urllib.request.Request(host+route,data=json.dumps(payload).encode() if payload is not None else None,headers={'Content-Type':'application/json'})
    with opener.open(query,timeout=2) as reply:
        assert reply.status==200
        return json.load(reply)
def state_now():
    state=request('state');assert state['transport']['profile']=='deterministic-local-test' and not state['transport']['automatic_clock'];return state
def log(name,body):
    with (work/name).open('a') as output: output.write(json.dumps(body,separators=(',',':'))+'\n')
def observe(state):
    route='evidence?'+urllib.parse.urlencode({'scenario_id':state['scenario_id'],'limit':32}); evidence=request(route); assert evidence['scenario_id']==state['scenario_id']; assert len(evidence['operations'])<32
    # The original command oracles consume all ordered operations. Store byte digests as independent data.
    return {'state':state,'evidence':evidence}
while True:
    if (work/'native-runtime.json').exists(): break
    path=work/'current.json'
    if not path.exists():time.sleep(.02);continue
    check=json.loads(path.read_bytes())['check']
    if current!=check:current=check;changed=time.monotonic()
    if time.monotonic()-changed>25:
        log('fixture-faults.jsonl',{'check':check,'error':'Original 25-second per-check watchdog expired'});break
    if source.exists():
        cmd=json.loads(source.read_bytes()); token=cmd['token']
        if token!=last:
            last=token;assert token.isascii() and token.isdigit() and len(token)<24
            try:
                state=state_now()
                if cmd['action']=='feed' and type(cmd.get('value')) is bool and set(cmd)=={'token','action','value'}:
                    feeding=cmd['value']; answer={'state':state}
                elif cmd['action']=='tick' and set(cmd) <= {'token','action','ticks'}:
                    request('control',dict(action='STEP',expected_epoch=state['epoch'],expected_revision=state['revision'],ticks=cmd.get('ticks',1)));state=state_now();answer={'state':state}
                elif cmd['action']=='observe' and set(cmd)=={'token','action'}: answer=observe(state)
                else: raise ValueError('Unexpected external fixture action')
                log('fixture-transitions.jsonl',{'check':check,'command':cmd,'epoch':state['epoch'],'revision':state['revision'],'scenario_id':state['scenario_id'],'ack_sequence':state['ack_sequence'],'state_sha256':hashlib.sha256(json.dumps(state,sort_keys=True).encode()).hexdigest()})
            except Exception as error:answer={'error':type(error).__name__+': '+str(error)}
            tmp=work/('fixture-'+token+'.tmp'); tmp.write_text(json.dumps(answer));tmp.replace(work/('fixture-'+token+'.json'))
    if feeding and time.monotonic()>=clock:
        state=state_now()
        step={'action':'STEP','expected_epoch':state['epoch'],'expected_revision':state['revision']}
        try: updated=request('control',step)
        except urllib.error.HTTPError as exc:
            # Synthetic command execution may change the revision between the read and STEP. Only retry the next regular clock tick.
            if exc.code!=409: raise
        else:log('clock.jsonl',{'check':check,'request':step,'response_sha256':hashlib.sha256(json.dumps(updated,sort_keys=True).encode()).hexdigest()})
        clock=time.monotonic()+.5
    time.sleep(.01)

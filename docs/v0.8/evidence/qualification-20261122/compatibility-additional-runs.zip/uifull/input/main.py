import os,sys
os.chdir('/workspace/native-language-results')
sys.path.insert(0,'/source')
import ui_contracts
import v08_native_language_batch as observer
observer.SPECS=(*observer.SPECS,{'name':'uifull','files':['ui_contracts.py']})
observer.write_runtime_identity('uifull')

import os,sys
os.chdir('/workspace/native-language-results')
sys.path.insert(0,'/source')
import common_contracts
import v08_native_language_batch as observer
observer.SPECS=(*observer.SPECS,{'name':'commonfull','files':['common_contracts.py']})
observer.write_runtime_identity('commonfull')

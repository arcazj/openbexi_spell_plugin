import os
from pathlib import Path
from spell.lang.functions import CreateDictionary, LoadDictionary, SaveDictionary, Display
from spell.lang.constants import HEX, BIN
from spell.lib.adapter.utctime import TIME
from spell.lib.exception import DriverException, SyntaxException
def call(function,*args,**kwargs):
    return function(*args,HandleError=False,**kwargs)
def rejects(kind,function):
    try: function()
    except kind: return
    raise AssertionError('Expected '+kind.__name__)
path=Path(os.environ['SPELL_DATA'])/'User/MyData/data.IMP'
uri='usr://MyData/data'
EXAMPLE="KEY1 45.67\nKEY2 This is a string\nKEY3 'This is another string'\nKEY4 2007/01/23 10:30\nKEY5 0b011001\nKEY6 [0,1,2,3,4]\nKEY7 {'A':24, 'B':34, 'C':['X','Y','Z']}\n"

path.write_text(EXAMPLE,encoding='utf-8')
db=call(LoadDictionary,uri)
assert db['KEY1']==45.67
assert db['KEY2']=='This is a string'
assert db['KEY3']=='This is another string'
assert db['KEY4'].value()==TIME('2007/01/23 10:30').value()
assert db['KEY5']==0b011001
assert db['KEY6']==[0,1,2,3,4] and db['KEY6'][1]==1
assert db['KEY7']=={'A':24,'B':34,'C':['X','Y','Z']} and db['KEY7']['C'][2]=='Z'
assert call(SaveDictionary,db) is True
assert 'KEY5\t0b011001\n' in path.read_text(encoding='utf-8')
db=call(LoadDictionary,uri)
assert db['KEY4'].value()==TIME('2007/01/23 10:30').value() and db['KEY7']['C'][2]=='Z'

Display('USER_DATABASE_PASSED')

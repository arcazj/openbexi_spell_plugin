from pathlib import Path
import ast,hashlib,json,sys,shutil
r=Path('C:/projects/openbexi_spell_plugin');w=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'conformance'));import user_database_cases as cases
old=json.loads((r/'conformance/evidence/user_database.json').read_bytes());control=(r/'conformance/user_database_controller.py').read_bytes();program=(r/'conformance/user_database_cases.py').read_bytes(); assert hashlib.sha256(control).hexdigest()==old['inputs']['conformance/user_database_controller.py'] and hashlib.sha256(program).hexdigest()==old['inputs']['conformance/user_database_cases.py'];tree=ast.parse(control);preludes=[n.value.value for n in ast.walk(tree) if isinstance(n,ast.Assign) and isinstance(n.value,ast.Constant) and isinstance(n.value.value,str) and any(isinstance(t,ast.Name) and t.id=='prelude' for t in n.targets)];assert len(preludes)==1
core='sha256:1426fbd0b032ebe86f128474f27ac20e2b12200a3c544a7467c5b8f05e98100d';edge='sha256:fdd6bf0f754c414d846b7199b1bddeaf4cea5d70a899ba7878a3de4bc6e80ac8';worker='sha256:a545c9617133bfc8034f385ef0ffb71c5eb2cfc9a74fd078838ee33bdf6753d4'; template=w/'dta';
for ix,(g,dim) in enumerate((g,d) for g in ('load','formats','revert') for d in ('positive','boundary','failure','recovery')):
 key=g+':'+dim;src=cases.CASES[key]['source'];assert old['checks'][key]['source']==src;name='dict'+g+dim;sub=w/name;sub.mkdir(exist_ok=True);sd=sub/'input';sd.mkdir(exist_ok=True);(sub/'original-selection.json').write_bytes((json.dumps({'key':key,'original':old['checks'][key],'prelude_sha256':hashlib.sha256(preludes[0].encode()).hexdigest(),'original_sources':{'conformance/user_database_cases.py':hashlib.sha256(program).hexdigest(),'conformance/user_database_controller.py':hashlib.sha256(control).hexdigest()}},indent=2)+'\n').encode());source=preludes[0]+'EXAMPLE='+repr(cases.EXAMPLE)+'\n'+src+"\nDisplay('USER_DATABASE_PASSED')\n";(sd/'original_case.py').write_bytes(source.encode());shutil.copyfile(template/'input/v08_native_language_batch.py',sd/'v08_native_language_batch.py');main="""import hashlib,json,os,sys,traceback
from pathlib import Path
os.chdir('/workspace/native-language-results')
sys.path.insert(0,'/source')
owned=Path(os.environ['SPELL_DATA'])/'User/MyData';owned.mkdir(parents=True)
file=Path('/source/original_case.py');result={}
try:
    exec(compile(file.read_bytes(),str(file),'exec'),{'__name__':'__main__','__file__':str(file)})
    result={'passed':True}
except Exception as error:
    result={'passed':False,'error':type(error).__name__+': '+str(error),'traceback':traceback.format_exc()}
    raise
finally:
    target=owned/'data.IMP';result.update(source_sha256=hashlib.sha256(file.read_bytes()).hexdigest(),directory=sorted(p.name for p in owned.iterdir()),file_sha256=hashlib.sha256(target.read_bytes()).hexdigest() if target.is_file() else None)
    Path('dictionary-results.json').write_text(json.dumps(result,indent=2))
    import v08_native_language_batch as observer
    observer.SPECS=(*observer.SPECS,{'name':SUITE,'files':['original_case.py']})
    observer.write_runtime_identity(SUITE)
""".replace('SUITE',repr(name));(sd/'main.py').write_bytes(main.encode());p=(template/'start_case.py').read_text().replace('sha256:de617ca4c3e0d2550bd639c201182f3f36ee21de6d7fd232e17fead8a47e47f3',worker).replace('sha256:6189fc60d20bcfd14ae40f10010fcd2cc0c79a9ac70da3118c05c8e2c5dd6583',core).replace('10.237.193.','10.238.'+str(ix+1)+'.').replace('"--network","none","--entrypoint","python","-e","WORKER_IMAGE="','"--network","none","--user","0:0","--entrypoint","python","-e","WORKER_IMAGE="').replace('volume-subpath={src}"','volume-subpath={src},volume-nocopy"').replace('mount(role,"/credentials")]','mount(role,"/credentials")]\n    if role!="worker":common[common.index("--user")+1]="65532:65532"').replace('images["server"],role,"--config"','("'+edge+'" if role=="gateway" else images["server"]),role,"--config"').replace('volume=volume,worker_memory_mib=1536','volume=volume,worker_memory_mib=1536,gateway_image="'+edge+'")').replace('"'+edge+'"))','"'+edge+'")');(sub/'start655.py').write_bytes(p.encode());compile(p,'start','exec');p=(w/'obsmore/setup_case.py').read_text();p=p.replace('driver_binding="simulator"','driver_binding="context-audit"');p='\n'.join(l for l in p.splitlines() if not l.startswith('context["native_driver"]'))+'\n';(sub/'setup_case.py').write_bytes(p.encode())

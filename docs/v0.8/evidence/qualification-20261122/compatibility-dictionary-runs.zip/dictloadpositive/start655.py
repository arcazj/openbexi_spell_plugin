import argparse
import json
import re
import socket
import subprocess
import time
from pathlib import Path
from importlib.util import spec_from_file_location, module_from_spec

base=Path(__file__).parent.resolve()
parser=argparse.ArgumentParser()
parser.add_argument("name")
args=parser.parse_args()
assert re.fullmatch("[a-z0-9]+",args.name)
name="obx-compat-"+args.name
work=base/args.name
work.mkdir(mode=0o700,exist_ok=True)
assert not (work/"case.json").exists()
def docker(*args):
    return subprocess.check_output(["docker",*map(str,args)],text=True).strip()
volume=name+"-case"
docker("volume","create",volume)
edge,service,worker_net=(name+"-"+role for role in ("edge","service","private"))
for index,network in enumerate((edge,service,worker_net)):
    if subprocess.run(["docker","network","inspect",network],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0:
        old=json.loads(docker("network","inspect",network))[0]
        assert old["Name"]==network and old["Internal"]==(network!=edge) and not old["Containers"]
        continue
    subnet="10.238.1."+str((0+index)*32)+"/27"
    docker("network","create","--subnet",subnet,*(["--internal"] if network!=edge else []),network)
images={"runtime":"sha256:a545c9617133bfc8034f385ef0ffb71c5eb2cfc9a74fd078838ee33bdf6753d4","server":"sha256:1426fbd0b032ebe86f128474f27ac20e2b12200a3c544a7467c5b8f05e98100d"}
for value in images.values():
    assert docker("image","inspect","--format","{{.Id}}",value)==value
with socket.socket() as sock:
    sock.bind(("127.0.0.1",0))
    port=sock.getsockname()[1]
setup=name+"-setup"
docker("create","--name",setup,"--network","none","--user","0:0","--entrypoint","python","-e","WORKER_IMAGE="+images["runtime"],"-e","PUBLIC_PORT="+str(port),
       "--mount",f"type=volume,src={volume},dst=/case",images["server"],"-I","/setup.py")
docker("cp",base/"setup_case.py",setup+":/setup.py")
docker("cp",base/"input",setup+":/input")
subprocess.run(["docker","start","--attach",setup],check=True)
docker("cp",setup+":/case/case.json",work/"case.json")
for subject in ("alice","observer"):
    private=work/subject
    private.mkdir(mode=0o700)
    docker("cp",setup+":/case/"+subject+"/.",private)
docker("rm",setup)
def mount(src,dst,ro=True):
    return ["--mount",f"type=volume,src={volume},dst={dst},volume-subpath={src},volume-nocopy"+(",readonly" if ro else "")]
for role,network in (("context",service),("listener",edge),("gateway",edge),("worker",worker_net)):
    cnt=name+"-"+role
    common=["--name",cnt,"--network",network,"--network-alias",role,"--init","--read-only","--user","10003:10003","--cap-drop","ALL","--security-opt","no-new-privileges","--pids-limit","256",*mount(role,"/credentials")]
    if role!="worker":common[common.index("--user")+1]="65532:65532"
    if role=="worker":
        command=[*common,"--memory","1536m","--memory-swap","1536m","--cpus","2","--tmpfs","/tmp:rw,nosuid,nodev,size=128m",
                 "--tmpfs","/workspace:rw,nosuid,nodev,size=16m,mode=0700,uid=10003,gid=10003","--env","OPENBEXI_V08_AUDIT_ROOT=/audit",*mount("audit","/audit",False),
                 *mount("snapshot","/source"),*mount("oracle-output","/workspace/native-language-results",False),images["runtime"]]
    else:
        if role=="context":
            common+=[*mount("git","/git"),*mount("state","/state",False)]
        if role=="gateway":
            common+=["--publish",f"127.0.0.1:{port}:9443"]
        command=[*common,"--tmpfs","/tmp:rw,nosuid,nodev,size=8m",("sha256:fdd6bf0f754c414d846b7199b1bddeaf4cea5d70a899ba7878a3de4bc6e80ac8" if role=="gateway" else images["server"]),role,"--config","/credentials/config.json"]
    docker("create",*command)
    if role=="context":
        docker("network","connect","--alias","context",worker_net,cnt)
    if role=="listener":
        docker("network","connect","--alias","listener",service,cnt)
    docker("start",cnt)
    for i in range(50):
        status=docker("inspect","--format","{{.State.Status}}",cnt)
        if status!="running":
            raise RuntimeError(role+" exited: "+docker("logs",cnt))
        if role=="worker" or '"port": 9443' in docker("logs",cnt):
            break
        time.sleep(0.1)
    else:
        raise TimeoutError(role+" did not listen")
cfg=json.loads((work/"case.json").read_text())
cfg.update(prefix=name,server_image=images["server"],worker_image=images["runtime"],networks=[edge,service,worker_net],volume=volume,worker_memory_mib=1536,gateway_image="sha256:fdd6bf0f754c414d846b7199b1bddeaf4cea5d70a899ba7878a3de4bc6e80ac8")
(work/"case.json").write_text(json.dumps(cfg,indent=2)+"\n")
print(json.dumps(cfg))

import hashlib,json,os,sys,traceback
from pathlib import Path
os.chdir('/workspace/native-language-results')
sys.path.insert(0,'/source')
owned=Path(os.environ['SPELL_DATA'])/'User/MyData';owned.mkdir(parents=True)
file=Path('/source/original_case.py');result={}
try:
    exec(compile(file.read_bytes(),str(file),'exec'),{'__name__':'__main__','__file__':str(file)})
    result={'passed':True}
except Exception as error:
    result={'passed':False,'error':type(error).__name__+': '+str(error),'traceback':traceback.format_exc()}
    raise
finally:
    target=owned/'data.IMP';result.update(source_sha256=hashlib.sha256(file.read_bytes()).hexdigest(),directory=sorted(p.name for p in owned.iterdir()),file_sha256=hashlib.sha256(target.read_bytes()).hexdigest() if target.is_file() else None)
    Path('dictionary-results.json').write_text(json.dumps(result,indent=2))
    import v08_native_language_batch as observer
    observer.SPECS=(*observer.SPECS,{'name':'dictformatsrecovery','files':['original_case.py']})
    observer.write_runtime_identity('dictformatsrecovery')

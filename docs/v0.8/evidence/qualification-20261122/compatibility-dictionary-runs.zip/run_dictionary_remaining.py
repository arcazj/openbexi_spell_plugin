from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
import json,subprocess,sys
w=Path(__file__).resolve().parent
cases=[('dict'+g+d,'db'+g+d[0]) for g in ('load','formats','revert') for d in ('positive','boundary','failure','recovery') if (g,d)!=('load','positive')]
def run(pair):
 suite,name=pair;p=subprocess.run([sys.executable,'run_dictionary.py',suite,name],cwd=w,capture_output=True,text=True,timeout=230);print(suite,p.returncode,p.stdout[-155:],p.stderr[-190:],flush=True);return (suite,name,p.returncode)
with ThreadPoolExecutor(max_workers=2) as pool:
 out=[future.result() for future in as_completed([pool.submit(run,p) for p in cases])]
(w/'dictionary-batch.json').write_bytes((json.dumps(out,indent=2)+'\n').encode());assert all(code==0 for _,_,code in out)

import os
from pathlib import Path
from spell.lang.functions import CreateDictionary, LoadDictionary, SaveDictionary, Display
from spell.lang.constants import HEX, BIN
from spell.lib.adapter.utctime import TIME
from spell.lib.exception import DriverException, SyntaxException
def call(function,*args,**kwargs):
    return function(*args,HandleError=False,**kwargs)
def rejects(kind,function):
    try: function()
    except kind: return
    raise AssertionError('Expected '+kind.__name__)
path=Path(os.environ['SPELL_DATA'])/'User/MyData/data.IMP'
uri='usr://MyData/data'
EXAMPLE="KEY1 45.67\nKEY2 This is a string\nKEY3 'This is another string'\nKEY4 2007/01/23 10:30\nKEY5 0b011001\nKEY6 [0,1,2,3,4]\nKEY7 {'A':24, 'B':34, 'C':['X','Y','Z']}\n"

path.write_text("KEY 42\nTEXT 'caf\u00e9'\n",encoding='utf-8')
db=call(LoadDictionary,uri)
assert db['KEY']==42 and db['TEXT']=='caf\u00e9'

Display('USER_DATABASE_PASSED')

import time

with open('/workspace/viewer-capacity-start', 'w') as stream:
    stream.write('started')
time.sleep(14)
with open('/workspace/approved-procedure-completed', 'w') as stream:
    stream.write('all observers watched the same native execution')

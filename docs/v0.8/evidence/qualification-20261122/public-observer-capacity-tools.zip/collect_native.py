"""Collect bounded, secret-free source, process, database, and storage evidence."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

base=Path(__file__).parent.resolve()
parser=argparse.ArgumentParser()
parser.add_argument("case")
parser.add_argument("gui",type=Path)
parser.add_argument("--final",action="store_true")
parser.add_argument("--service-uid",type=int,choices=(10003,65532),default=10003)
parser.add_argument("--prompt",action="store_true")
args=parser.parse_args()
folder=base/args.case
case=json.loads((folder/"case.json").read_text())
prefix=case["prefix"]
def docker(*args):
    return subprocess.check_output(["docker",*map(str,args)],text=True)
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
worker=prefix+"-worker"
container=json.loads(docker("inspect",worker))[0]
assert container["State"]["Status"]=="exited" and container["State"]["ExitCode"]==0
raw=docker("logs","--timestamps",worker)
(folder/"worker.log").write_text(raw)
entries=[dict(json.loads(line.split(" ",1)[1]),time=line.split(" ",1)[0]) for line in raw.splitlines() if " {" in line]
native=[e for e in entries if e["event"] in ("native-ready","native-running","native-finished")]
observed=[e["event"] for e in native]
assert observed==["native-ready","native-running","native-finished"] or (args.prompt and observed==["native-ready","native-finished"] and any(e.get("native_status")=="PROMPT" for e in entries))
assert native[0]["native_status"]=="PAUSED" and native[-1]["native_status"]=="FINISHED" and native[-1]["native_lifecycle_receipts_settled"]
execution=native[-1]["execution_id"]
assert all(e["execution_id"]==execution for e in native)
diag=next(e for e in entries if e["event"]=="native-startup-diagnostics")["diagnostic"]
processes=[{k:v for k,v in row.items() if k in ("pid","executable","ppid")} for row in diag["processes"]]
programs={row["executable"]:row for row in processes}
assert programs["SPELL-Context"]["ppid"]==programs["SPELL-Listener"]["pid"]
assert programs["SPELL-Executor"]["ppid"]==programs["SPELL-Context"]["pid"]
audit_script="""
from pathlib import Path
import hashlib,json
files=sorted(p for p in Path('/audit').rglob('*') if p.is_file())
print(json.dumps([dict(name=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]))
"""
audit=json.loads(docker("run","--rm","--network","none","--read-only","--cap-drop","ALL","--security-opt","no-new-privileges",
    "--mount","type=volume,src="+case["volume"]+",dst=/audit,volume-subpath=audit,readonly","--user","10003:10003","--entrypoint","python",case["server_image"],"-I","-c",audit_script))
database_script="""
import hashlib,json,sqlite3
d=sqlite3.connect('file:/state/context.sqlite3?mode=ro',uri=True)
d.row_factory=sqlite3.Row
ev=[(t,json.loads(b)) for t,b in d.execute('SELECT type,body FROM events ORDER BY sequence')]
states=[dict(r) for r in d.execute('SELECT id,procedure_id,owner,lifecycle,control_state FROM executions')]
has=d.execute("SELECT 1 FROM sqlite_schema WHERE name='assigned_native_results'").fetchone()
results=[dict(r) for r in d.execute('SELECT execution_id,native_status FROM assigned_native_results')] if has else []
events=[dict(type=t,execution_id=v.get('execution_id')) for t,v in ev if 'execution_id' in v]
print(json.dumps(dict(executions=states,results=results, events=events,spent_workers=d.execute('SELECT SUM(spent) FROM workers').fetchone()[0], native_members=[dict(r) for r in d.execute('SELECT target_id,instance_id,pid,parent_pid,executable_sha256,state FROM native_members')],driver_events=[dict(scope=v['scope'],message_sha256=hashlib.sha256(v['message'].encode()).hexdigest()) for t,v in ev if t=='NATIVE_DRIVER_EVENT'])))
"""
authoritative=json.loads(docker("exec",prefix+"-context","python","-I","-c",database_script))
if args.prompt:
    script="import json,sqlite3;d=sqlite3.connect('file:/state/context.sqlite3?mode=ro',uri=True);print(json.dumps(d.execute('SELECT execution_id,state,outcome FROM native_prompts').fetchall()))"
    authoritative["prompt_states"]=json.loads(docker("exec",prefix+"-context","python","-I","-c",script))
    assert authoritative["prompt_states"]==[[execution,"CLOSED","ANSWER_SELECTED"]]
assert authoritative["spent_workers"]==1 and authoritative["executions"][0]["id"]==execution and len(authoritative["native_members"])==1
if args.final:
    assert authoritative["results"]==[dict(execution_id=execution,native_status="FINISHED")]
assert len(authoritative["driver_events"])==2 and audit
gui=json.loads(args.gui.read_text())
assert gui["passed"] and (gui.get("execution_id")==execution or gui.get("execution")==execution or any(e.get("execution_id")==execution for e in gui.get("events",[])))
uids={}
for role in ("context","listener","gateway","worker"):
    holds=json.loads(docker("inspect",prefix+"-"+role))[0]
    assert holds["HostConfig"]["ReadonlyRootfs"] and holds["HostConfig"]["CapDrop"]==["ALL"]
    assert "no-new-privileges" in holds["HostConfig"]["SecurityOpt"]
    uid=10003 if role=="worker" else args.service_uid
    uids[role]=holds["Config"]["User"]
    assert uids[role]==f"{uid}:{uid}"
    assert holds["Image"]==(case["worker_image"] if role=="worker" else case["server_image"] if role=="gateway" else case.get("core_image",case["server_image"]))
docker("cp",worker+":/opt/v08-native-home/build.json",folder/"native-build.json")
receipt=dict(case=case,worker_container=container["Id"],worker_exit=container["State"]["ExitCode"],
    native=native,native_processes=processes,authority=authoritative,audit_files=audit,protocol_result_sha256=sha(args.gui),worker_log_sha256=sha(folder/"worker.log"),
    native_build_sha256=sha(folder/"native-build.json"),role_containment=dict(readonly_root=True,dropped_capabilities=["ALL"],user_by_role=uids,no_new_privileges=True),
    fixture_tools_sha256={p.name:sha(p) for p in (base/"start_case.py",base/"setup_case.py",Path(__file__))})
(folder/"public-result.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(dict(result=sha(folder/"public-result.json"),execution=execution,processes=processes,asrun_files=len(audit),native_results=authoritative["results"])))

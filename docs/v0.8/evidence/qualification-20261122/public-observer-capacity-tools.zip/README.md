# Single-Gateway observer capacity

Use an isolated Docker Desktop host running Linux containers, the pinned IDE `1.2.2` Python client, the four local image IDs in `public-observer-capacity-47e.json`, and the pure-Python `wsproto` and `h11` wheels from the delivery lock. The script verifies their SHA-256 digests before loading them. The fixture publishes a single loopback Gateway and generates separate one-day certificates. Store the generated private case directory and named volume under the operator's control.

```text
python start_case.py observers47 --output-root CASE_ROOT --browser --procedure observer_procedure.py --server GATEWAY_IMAGE --core CORE_IMAGE --runtime WORKER_IMAGE --provisioner ISSUER_IMAGE --service-uid 65532 --lab-net 62
python -I measure.py ABSOLUTE_CASE_DIRECTORY BROWSER_WHEEL_DIRECTORY
python collect_native.py ABSOLUTE_CASE_DIRECTORY ABSOLUTE_CASE_DIRECTORY/capacity.json --service-uid 65532 --final
python close_case.py ABSOLUTE_CASE_DIRECTORY
```

Use an unused case name and subnet. One authorized controller starts the immutable audit-only procedure at PAUSED. Each of 101 other client identities verifies its read-only permissions and observes the same original execution through the installed HTTPS client. Thirty-two also keep an origin-checked WSS replay connection open. One additional stream request checks the fixed admission boundary. The controller explicitly issues Run only after all 101 clients read the original root. Every viewer must read its state during the native RUNNING interval and see the final FINISHED result. The test limits concurrent HTTPS reads to eight and uses no Chromium processes.

`capacity.json` records the phased observations and transport counts. `observers.json` records certificate fingerprints, individual snapshot times and replay cursors. `public-result.json` independently checks the original native ancestry, audit files, authority result and role containment. The deployed capacity manifest accompanying the original receipt additionally verifies the installed Gateway source hashes against the canonical server wheel.

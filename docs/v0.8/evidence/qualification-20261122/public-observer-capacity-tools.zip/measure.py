"""Measure one fixture-owned native root with 101 authenticated read-only clients."""
import asyncio
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
from importlib.metadata import version
import json
from pathlib import Path
import ssl
import subprocess
import sys
import time
from urllib.parse import urlsplit
import uuid

from openbexi_runtime.spell_server_client import SpellServerClient, SpellServerError

case=Path(sys.argv[1]).resolve()
wheel_dir=Path(sys.argv[2]).resolve()
for name,expected in {'h11-0.16.0-py3-none-any.whl':'63cf8bbe7522de3bf65932fda1d9c2772064ffb3dae62d55932da54b31cb6c86','wsproto-1.3.2-py3-none-any.whl':'61eea322cdf56e8cc904bd3ad7573359a242ba65688716b0710a5eb12beab584'}.items():
    wheel=wheel_dir/name
    assert sha256(wheel.read_bytes()).hexdigest()==expected
    sys.path.insert(0,str(wheel))
from wsproto import ConnectionType, WSConnection
from wsproto import events

cfg=json.loads((case/'case.json').read_text())
origin=json.loads((case/'alice/connection.json').read_text())['url']
url=urlsplit(origin)
assert url.hostname=='127.0.0.1' and cfg['prefix']=='obx-public-launch-'+case.name
subjects=['observer',*(f'watch-{n:02d}' for n in range(1,101))]
ws_roles=set(subjects[:32]); clients={name:SpellServerClient.from_config(case/name/'connection.json') for name in [*subjects,'alice']}
owner=clients['alice']
roster={name:{'fingerprint':sha256(ssl.PEM_cert_to_DER_cert((case/name/'tls.pem').read_text())).hexdigest(),'https':[],'wss':[]} for name in subjects}
assert len({r['fingerprint'] for r in roster.values()})==101
report={'passed':False,'case':cfg['prefix'],'subject_count':len(subjects),'events':[],'failures':[],
        'tool_versions':{'python':sys.version.split()[0],'installed_ide':version('openbexi-ide'),'wsproto':'1.3.2','h11':'0.16.0'},
        'peak_https_reads_in_flight':0,'active_websockets':0,'peak_websockets':0,'active_watchers':0,'peak_active_watchers':0,'static_gateway_handlers':48}

def utc():return datetime.now(timezone.utc).isoformat()
def record(event,**fields):
    report['events'].append(dict(event=event,utc=utc(),**fields));print(event,flush=True)
def write():
    (case/'observers.json').write_text(json.dumps(roster,indent=2)+'\n',newline='\n')
    (case/'capacity.json').write_text(json.dumps(report,indent=2)+'\n',newline='\n')
def docker(*args):return subprocess.check_output(['docker',*map(str,args)],text=True)
def worker_events():
    text=docker('logs','--timestamps',cfg['prefix']+'-worker'); rows=[]
    for line in text.splitlines():
        timestamp,raw=line.split(' ',1)
        if raw.startswith('{'):
            entry=json.loads(raw)
            if entry.get('event') in {'native-ready','native-running','native-finished','native-worker-failed'}:
                rows.append(dict(utc=timestamp,event=entry['event'],status=entry.get('native_status'),execution=entry.get('execution_id')))
    return rows

async def websocket(role):
    client=clients[role]
    reader,writer=await asyncio.wait_for(asyncio.open_connection(url.hostname,url.port,ssl=client.tls,server_hostname=url.hostname),3)
    try:
        cert=writer.get_extra_info('ssl_object').getpeercert(binary_form=True)
        assert sha256(cert).hexdigest()==client.fingerprint
        conn=WSConnection(ConnectionType.CLIENT)
        msg=events.Request(host=url.netloc,target='/workspace/contexts/A/events',subprotocols=['openbexi.events.v1'],extra_headers=[(b'origin',origin.encode())])
        writer.write(conn.send(msg));await writer.drain()
        while True:
            incoming=await asyncio.wait_for(reader.read(8192),4)
            if not incoming:raise RuntimeError('WebSocket upgrade closed')
            conn.receive_data(incoming)
            for response in conn.events():
                if isinstance(response,events.AcceptConnection):
                    assert response.subprotocol=='openbexi.events.v1'
                    return reader,writer,conn,101
                if isinstance(response,events.RejectConnection):
                    return reader,writer,conn,response.status_code
    except BaseException:
        writer.close();raise

async def run():
    # TLS and the original installed client enforce the normal request deadlines.
    # Only independent read operations share this client-side concurrency bound.
    slots=asyncio.Semaphore(8); active=0
    async def readcall(function,*args,**kw):
        nonlocal active
        async with slots:
            active+=1;report['peak_https_reads_in_flight']=max(active,report['peak_https_reads_in_flight'])
            try:return await asyncio.to_thread(function,*args,**kw)
            finally:active-=1
    async def identify(role):
        result=await readcall(clients[role].read,'A','health')
        assert result['subject']==role and set(result['permissions'])=={'context:read','execution:read'}
        roster[role]['identity_verified']=True
    await asyncio.gather(*(identify(r) for r in subjects))
    for role in (subjects[0],subjects[-1]):
        try:await readcall(clients[role].authority,'A','session.open',{},key=str(uuid.uuid4()))
        except SpellServerError as e:
            assert e.status==403;roster[role]['mutation_denied_status']=e.status
        else:raise RuntimeError('Read-only principal received authority')
    record('Verified exact read-only Context policy on 101 different client certificates')
    procedures=owner.read('A','procedures')['procedures']; entry=next(x for x in procedures if x['procedure_id']=='approved-main')
    conn=owner.authority('A','session.open',{},key=str(uuid.uuid4()))['connection_id']
    payload={k:entry[k] for k in ('procedure_id','source_revision','source_sha256','runtime_image','driver_binding')}
    reservation=owner.authority('A','execution.reserve',dict(payload,connection_id=conn),key=str(uuid.uuid4()))
    owner.remember_controller('A',reservation); eid=reservation['id'];report['execution']=eid
    await asyncio.to_thread(owner.launch,'A',eid,key=str(uuid.uuid4()))
    until=time.monotonic()+18
    while not any(x['event']=='native-ready' for x in await asyncio.to_thread(worker_events)):
        if time.monotonic()>until:raise TimeoutError('Original root did not pause')
        await asyncio.sleep(.2)
    record('Separate authenticated owner reserved and started one original native root in PAUSED')
    stop=asyncio.Event(); socket_tasks=[];view_tasks=[]; ready=set(); started=set();terminal=set()
    async def watch(role,index):
        report['active_watchers']+=1;report['peak_active_watchers']=max(report['active_watchers'],report['peak_active_watchers'])
        try:
            await asyncio.sleep(index*.022)
            while not stop.is_set():
                now=utc();result=await readcall(clients[role].read,'A','executions')
                row=next(v for v in result['executions'] if v['id']==eid)
                assert row['owner']=='alice' and row['native_root_registered']
                status=row.get('native_root_result')
                roster[role]['https'].append({'start_utc':now,'end_utc':utc(),'result':status})
                ready.add(role)
                if status=='FINISHED':terminal.add(role)
                elif status is not None:raise RuntimeError('Unexpected root state')
                await asyncio.sleep(2.4)
        except Exception as exc:
            report['failures'].append({'subject':role,'transport':'HTTPS','type':type(exc).__name__,'status':getattr(exc,'status',None)});raise
        finally:report['active_watchers']-=1
    async def stream(role,index):
        await asyncio.sleep(index*.065)
        reader,writer,proto,status=await websocket(role)
        try:
            if status!=101:raise RuntimeError('Initial stream rejected with '+str(status))
            report['active_websockets']+=1;report['peak_websockets']=max(report['active_websockets'],report['peak_websockets']);started.add(role)
            cursor=0
            while not stop.is_set():
                writer.write(proto.send(events.TextMessage(data=json.dumps({'after_sequence':cursor}))));await writer.drain()
                parts=[]; page=None
                while page is None:
                    data=await asyncio.wait_for(reader.read(32768),4)
                    if not data:raise RuntimeError('WebSocket disconnected')
                    proto.receive_data(data)
                    for event in proto.events():
                        if isinstance(event,events.TextMessage):
                            parts.append(event.data)
                            if event.message_finished:page=json.loads(''.join(parts))
                        elif isinstance(event,events.CloseConnection):raise RuntimeError('Stream closed with '+str(event.code))
                assert page['context_id']=='A' and page['after_sequence']==cursor and page['next_sequence']>=cursor
                cursor=page['next_sequence']
                roster[role]['wss'].append({'utc':utc(),'cursor':cursor,'types':[v['type'] for v in page['events']]})
                await asyncio.sleep(1.65)
        except Exception as exc:
            report['failures'].append({'subject':role,'transport':'WSS','type':type(exc).__name__,'reason':str(exc)[:96]});raise
        finally:
            if status==101:report['active_websockets']-=1
            writer.close()
    async def until(predicate,seconds):
        deadline=time.monotonic()+seconds
        while not predicate():
            for task in (*view_tasks,*socket_tasks):
                if task.done() and not task.cancelled():task.result()
            if time.monotonic()>deadline:raise TimeoutError('Observation condition expired')
            await asyncio.sleep(.08)
    try:
        socket_tasks=[asyncio.create_task(stream(role,n)) for n,role in enumerate(subjects[:32])]
        view_tasks=[asyncio.create_task(watch(role,n)) for n,role in enumerate(subjects)]
        await until(lambda:len(ready)==101 and len(started)==32 and all(roster[r]['wss'] for r in started),20)
        record('All 101 continuously active viewers saw the same native root; 32 WSS streams were open',simultaneous_wss=report['active_websockets'],active_viewers=report['active_watchers'])
        rd,wr,proto,code=await websocket(subjects[-1]);wr.close();assert code==503
        record('One additional authenticated WebSocket reached the documented per-Gateway boundary',http_status=code)
        issued=utc();cmd=await asyncio.to_thread(owner.command,'A',eid,'CMD_RUN',key=str(uuid.uuid4()))
        record('Owner Run admitted with all 101 read-only tasks and 32 sockets still active',issued=issued,admitted=cmd['admitted'],active_viewers=report['active_watchers'],active_websockets=report['active_websockets'])
        await until(lambda:len(terminal)==101,32)
        assert all(len(roster[r]['wss'])>=3 for r in ws_roles)
        record('Every identity read the original FINISHED result',active_viewers=report['active_watchers'],active_websockets=report['active_websockets'])
        assert report['active_watchers']==101 and report['active_websockets']==32
    finally:
        stop.set()
        await asyncio.gather(*view_tasks,*socket_tasks,return_exceptions=True)
        owner.forget()
    native=await asyncio.to_thread(worker_events);report['native']=native
    running=next(v['utc'] for v in native if v['event']=='native-running')
    done=next(v['utc'] for v in native if v['event']=='native-finished')
    def epoch(t):return datetime.fromisoformat(t.replace('Z','+00:00')).timestamp()
    mid=[role for role in subjects if any(epoch(running)<epoch(o['start_utc'])<epoch(o['end_utc'])<epoch(done) and o['result'] is None for o in roster[role]['https'])]
    assert len(mid)==101 and not report['failures']
    report.update(passed=True,https_readers=101,https_only_readers=69,wss_and_https_readers=32,observed_during_true_native_running=len(mid),terminal_readers=len(terminal),
                  min_https_reads=min(len(roster[r]['https']) for r in subjects),min_wss_pages=min(len(roster[r]['wss']) for r in ws_roles),
                  actual_concurrent_browser_processes=0,webdriver_used=False)

try:asyncio.run(run())
except Exception as e:
    report['error']={'type':type(e).__name__,'message':str(e)[:240]};raise
finally:write()

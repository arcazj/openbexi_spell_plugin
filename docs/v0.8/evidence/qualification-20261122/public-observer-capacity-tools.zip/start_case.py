import argparse
import json
import re
import socket
import subprocess
import time
from pathlib import Path
from importlib.util import spec_from_file_location, module_from_spec

base=Path(__file__).parent.resolve()
parser=argparse.ArgumentParser()
parser.add_argument("name")
parser.add_argument("--output-root", type=Path)
parser.add_argument("--runtime")
parser.add_argument("--server")
parser.add_argument("--core")
parser.add_argument("--provisioner")
parser.add_argument("--service-uid",type=int,choices=(10003,65532),default=10003)
parser.add_argument("--browser",action="store_true")
parser.add_argument("--procedure",type=Path)
parser.add_argument("--child",type=Path)
parser.add_argument("--handoff",action="store_true")
parser.add_argument("--lab-net",type=int,choices=range(1,200))
args=parser.parse_args()
if args.handoff and not (args.browser and args.procedure and args.child):
    raise ValueError("Private handoff case requires the browser and both immutable procedures")
assert re.fullmatch("[a-z0-9]+",args.name)
name="obx-public-launch-"+args.name
work=(args.output_root or base)/args.name
work.parent.mkdir(parents=True,exist_ok=True)
work.mkdir(mode=0o700)
def docker(*args):
    return subprocess.check_output(["docker",*map(str,args)],text=True).strip()
volume=name+"-case"
docker("volume","create",volume)
edge,service,worker_net=(name+"-"+role for role in ("edge","service","private"))
for index, network in enumerate((edge,service,worker_net)):
    subnet=["--subnet",f"198.19.{args.lab_net}.{index*32}/27"] if args.lab_net else []
    docker("network","create",*subnet,*(["--internal"] if network!=edge else []),network)
images={r:docker("image","inspect","--format","{{.Id}}",getattr(args,r) or "openbexi-public-launch-"+r+":20261122") for r in ("runtime","server")}
core=docker("image","inspect","--format","{{.Id}}",args.core) if args.core else images["server"]
with socket.socket() as sock:
    sock.bind(("127.0.0.1",0))
    port=sock.getsockname()[1]
setup=name+"-setup"
docker("create","--name",setup,"--user","0:0","--network","none","--entrypoint","python","-e","WORKER_IMAGE="+images["runtime"],"-e","PUBLIC_PORT="+str(port),
       "-e","SERVICE_UID="+str(args.service_uid),"-e","BROWSER_WORKSPACE="+str(int(args.browser)),"-e","HOST_HANDOFF="+str(int(args.handoff)),"--mount",f"type=volume,src={volume},dst=/case",args.provisioner or images["server"],"-I","/setup.py")
docker("cp",base/"setup_case.py",setup+":/setup.py")
if args.procedure:
    docker("cp",args.procedure.resolve(),setup+":/qualification-procedure.py")
if args.child:
    docker("cp",args.child.resolve(),setup+":/qualification-child.py")
if args.handoff:
    for source in ("private_host_rpc.py","kernel_observer.py"):
        docker("cp",base/source,setup+":/"+source)
subprocess.run(["docker","start","--attach",setup],check=True)
docker("cp",setup+":/case/case.json",work/"case.json")
for subject in (("alice","bob","observer", *(f"watch-{i:02d}" for i in range(1,101))) if args.browser else ("alice","observer")):
    private=work/subject
    private.mkdir(mode=0o700)
    docker("cp",setup+":/case/"+subject+"/.",private)
docker("rm",setup)
def mount(src,dst,ro=True):
    return ["--mount",f"type=volume,src={volume},dst={dst},volume-subpath={src}"+(",readonly" if ro else "")]
for role,network in (("context",service),("listener",edge),("gateway",edge),("worker",worker_net)):
    cnt=name+"-"+role
    uid=10003 if role=="worker" else args.service_uid
    common=["--name",cnt,"--network",network,"--network-alias",role,"--init","--read-only","--user",f"{uid}:{uid}","--cap-drop","ALL","--security-opt","no-new-privileges","--pids-limit","256",*mount(role,"/credentials")]
    if role=="worker":
        command=[*common,"--memory","1536m","--memory-swap","1536m","--cpus","2","--tmpfs","/tmp:rw,nosuid,nodev,size=128m",
                 "--tmpfs","/workspace:rw,nosuid,nodev,size=16m,mode=0700,uid=10003,gid=10003","--env","OPENBEXI_V08_AUDIT_ROOT=/audit",*mount("audit","/audit",False),
                 *mount("snapshot","/source"),*(mount("control","/control") if args.handoff else []),images["runtime"]]
    else:
        if role=="context":
            common+=[*mount("git","/git"),*mount("state","/state",False)]
        if role=="gateway":
            common+=["--publish",f"127.0.0.1:{port}:9443"]
        command=[*common,"--tmpfs","/tmp:rw,nosuid,nodev,size=8m",images["server"] if role=="gateway" else core,role,"--config","/credentials/config.json"]
    docker("create",*command)
    if role=="context":
        docker("network","connect","--alias","context",worker_net,cnt)
    if role=="listener":
        docker("network","connect","--alias","listener",service,cnt)
    if role=="worker" and args.handoff:
        continue
    docker("start",cnt)
    for i in range(50):
        status=docker("inspect","--format","{{.State.Status}}",cnt)
        if status!="running":
            raise RuntimeError(role+" exited: "+docker("logs",cnt))
        if role=="worker" or '"port": 9443' in docker("logs",cnt):
            break
        time.sleep(0.1)
    else:
        raise TimeoutError(role+" did not listen")
cfg=json.loads((work/"case.json").read_text())
cfg.update(prefix=name,server_image=images["server"],worker_image=images["runtime"],networks=[edge,service,worker_net],volume=volume,worker_memory_mib=1536)
cfg["core_image"]=core
if args.handoff:
    host=name+"-operator"
    docker("create","--name",host,"--network",service,"--user","10003:10003","--read-only","--cap-drop","ALL","--security-opt","no-new-privileges","--entrypoint","python",*mount("settlement-host","/credentials"),*mount("operator-code","/code"),*mount("control","/control",False),images["server"],"-I","-c","import time;time.sleep(3600)")
    docker("start",host)
    cfg["operator"]=host
(work/"case.json").write_text(json.dumps(cfg,indent=2)+"\n")
print(json.dumps(cfg))
